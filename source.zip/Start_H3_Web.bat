@echo off
chcp 65001 >nul
cd /d "%~dp0"
"python\python.exe" -X utf8 -s "web_portal\start.py"
if errorlevel 1 pause
