import json
import os
import subprocess
import time
import urllib.error
import urllib.request
import webbrowser
from pathlib import Path

root = Path(__file__).resolve().parent
bundle = root.parent


def available():
    try:
        with urllib.request.urlopen('http://127.0.0.1:8192/status', timeout=2) as response:
            return json.load(response).get('ready', False)
    except (OSError, ValueError):
        return False


if __name__ == '__main__':
    if not available():
        environment = os.environ.copy()
        settings = root / 'private/settings.json'
        if settings.exists():
            environment['PORTAL_ORIGINS'] = ','.join(json.loads(settings.read_text(encoding='utf-8')).get('origins', []))
        process = subprocess.Popen([str(bundle / 'python/python.exe'), '-X', 'utf8', '-s', str(root / 'server.py')],
                                   cwd=bundle, env=environment, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL,
                                   creationflags=subprocess.CREATE_NO_WINDOW)
        for _ in range(120):
            if available():
                break
            if process.poll() is not None:
                raise SystemExit('网页服务未能启动。请检查是否已有同一服务或端口占用。')
            time.sleep(1)
        else:
            raise SystemExit('启动超时，请检查本机工作进程。')
    webbrowser.open('http://127.0.0.1:8192/')
    print('本机任务看板：http://127.0.0.1:8192/')
