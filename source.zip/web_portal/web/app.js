'use strict';
let token = '';
let poll;
let downloading = false;
let archiveEnabled = false;
const receipts = new Map();
const downloadLinks = new Map();
const $ = id => document.getElementById(id);
function updateResolution() {
  const fullHD = $('resolution').value === '1080p';
  const native = $('resolution').value === '768p';
  const limit = fullHD ? 15 : 30;
  for (const option of $('seconds').options) {
    option.disabled = Number(option.value) > limit;
    option.hidden = option.disabled;
  }
  if (Number($('seconds').value) > limit) $('seconds').value = String(limit);
  $('orientation').options[0].textContent = fullHD ? '横屏 · 1920 × 1080' : native ? '横屏 · 1344 × 768' : '横屏 · 1280 × 720';
  $('orientation').options[1].textContent = fullHD ? '竖屏 · 1080 × 1920' : native ? '竖屏 · 768 × 1344' : '竖屏 · 720 × 1280';
  $('resolution-hint').textContent = fullHD ? '1080p 最长15秒，单段生成。' : native ? '768p 最长30秒，单段生成；画质优先建议从此分辨率开始。' : '720p 最长30秒，单段生成。';
}
$('resolution').addEventListener('change', updateResolution);
$('model').addEventListener('change', () => {
  if ($('model').value === 'h3-quality') $('resolution').value = '768p';
  updateResolution();
});
updateResolution();
const base = (window.PORTAL_API || (['localhost', '127.0.0.1'].includes(location.hostname) ? location.origin : '')).replace(/\/$/, '');
async function api(path, options = {}) {
  if (!base) throw new Error('远程工作站尚未连接，请联系管理员。');
  let response;
  try {
    response = await fetch(base + path, {cache: 'no-store', ...options, headers: {...(options.body instanceof FormData ? {} : {'Content-Type': 'application/json'}), ...(token ? {'Authorization': 'Bearer ' + token} : {}), ...options.headers}});
  } catch (_) { throw new Error('无法连接工作站，请确认工作站已启动。'); }
  const data = await response.json();
  if (!response.ok) throw new Error(data.error || '请求失败');
  return data;
}
async function refresh() {
  try {
    const data = await api('/api/tasks'); $('service-message').textContent = data.message;
    archiveEnabled = Boolean(data.archive);
    const selectedModel = $('model').value;
    $('model').replaceChildren(...(data.models || []).map(model => {
      const option = new Option(model.name + (model.available ? '' : ' · 未安装'), model.id);
      option.disabled = !model.available;
      return option;
    }));
    if (Array.from($('model').options).some(o => o.value === selectedModel && !o.disabled)) $('model').value = selectedModel;
    $('submit-button').disabled = !data.accepting_tasks || data.tasks.some(t => ['uploading','queued','running','ready','downloading','archive_pending'].includes(t.state));
    if (!downloading) renderTasks(data.tasks);
  }
  catch (error) { $('service-message').textContent = error.message; }
}
$('login-form').addEventListener('submit', async event => {
  event.preventDefault(); $('login-button').disabled = true; $('login-message').textContent = '';
  try {
    const result = await api('/api/login', {method: 'POST', body: JSON.stringify({username: $('username-input').value.trim(), password: $('password-input').value})});
    token = result.token; $('password-input').value = ''; $('username').textContent = result.username;
    $('login-panel').hidden = true; $('workspace').hidden = false; $('identity').hidden = false;
    await refresh(); poll = setInterval(refresh, 5000);
  } catch (error) { $('login-message').textContent = error.message; }
  finally { $('login-button').disabled = false; }
});
function renderTasks(tasks) {
  const container = $('tasks'); container.replaceChildren();
  if (!tasks.length) {
    const empty = document.createElement('div'); empty.className = 'empty';
    const title = document.createElement('h2'); title.textContent = '暂无运行任务';
    const subtitle = document.createElement('p'); subtitle.textContent = '提交后在这里查看状态并下载结果。';
    empty.append(title, subtitle); container.append(empty); return;
  }
  for (const task of tasks) {
    const row = document.createElement('article'); row.className = 'task-row';
    const body = document.createElement('div'); const name = document.createElement('h2');
    name.textContent = '任务 ' + task.id.slice(0, 8);
    const status = document.createElement('p'); status.textContent = task.message;
    body.append(name, status); row.append(body);
    if (task.state === 'ready') {
      const ticket = downloadLinks.get(task.id);
      if (ticket && ticket.expires * 1000 > Date.now()) {
        const link = document.createElement('a'); link.className = 'download';
        link.href = base + ticket.path; link.textContent = '下载视频 / 右键另存为';
        link.referrerPolicy = 'no-referrer';
        link.onclick = () => { $('task-message').textContent = '请在浏览器下载列表（Ctrl+J）查看进度。结果仍保留，下载失败可再次点击。'; };
        row.append(link);
        const done = document.createElement('button'); done.className = 'quiet';
        done.textContent = '确认已保存，完成任务';
        done.onclick = () => {
          if (confirm('请确认视频已下载完整且能正常播放。确认后将关闭下载入口，并清理主账号的工作站副本。')) acknowledge(task.id, ticket.receipt);
        };
        row.append(done);
      } else {
        const button = document.createElement('button'); button.className = 'download';
        button.textContent = '获取下载链接';
        button.onclick = () => prepareDownload(task.id);
        row.append(button);
      }
    }
    if (['ready','queued','failed'].includes(task.state)) {
      const cancel = document.createElement('button'); cancel.className = 'quiet'; cancel.textContent = '放弃并清理';
      cancel.onclick = async () => {
        if (!confirm('放弃该任务并删除工作站上的临时文件？')) return;
        try { await api('/api/tasks/' + task.id, {method:'DELETE'}); await refresh(); }
        catch(error) { $('task-message').textContent=error.message; }
      }; row.append(cancel);
    }
    container.append(row);
  }
}
async function acknowledge(id, receipt) {
  try {
    await api('/api/tasks/' + id + '/downloaded', {method:'POST',body:JSON.stringify({receipt,confirmed_saved:true})});
    receipts.delete(id); downloadLinks.delete(id); $('task-message').textContent = archiveEnabled ? '下载完成，账号归档已保留。' : '下载完成，工作站上的输入和结果已删除。'; await refresh();
  } catch(error) { receipts.set(id,receipt); $('task-message').textContent = '文件已保存，但清理确认失败。请点击任务旁的清理按钮重试。'; }
}
async function prepareDownload(id) {
  try {
    const ticket = await api('/api/tasks/' + id + '/download-link', {method:'POST'});
    downloadLinks.set(id, ticket);
    $('task-message').textContent='下载链接已准备好（1小时内有效）。点击下载，或右键选择“链接另存为”。下载进度在浏览器下载列表中查看；确认保存前不会自动清理。';
    await refresh();
  } catch(error) { $('task-message').textContent=error.message; }
}
$('task-form').addEventListener('submit',async event=>{
  event.preventDefault(); $('submit-button').disabled=true; $('task-message').textContent='正在上传…';
  try {
    const data=new FormData($('task-form'));
    await api('/api/tasks',{method:'POST',body:data});
    $('task-form').reset(); updateResolution(); $('task-message').textContent='任务已提交，输入内容已从表单清空。'; await refresh();
  } catch(error) { $('task-message').textContent=error.message; $('submit-button').disabled=false; }
});
if (document.modelContext?.registerTool) {
  document.modelContext.registerTool({name:'get_my_task_status',description:'读取当前登录账号的任务状态，不返回素材、提示词或结果。',inputSchema:{type:'object',properties:{},additionalProperties:false},annotations:{readOnlyHint:true},execute:async()=>{const data=await api('/api/tasks');await refresh();return {tasks:data.tasks};}});
}
$('logout').addEventListener('click', async () => {
  try { await api('/api/logout', {method: 'POST'}); } catch (_) {}
  token = ''; downloadLinks.clear(); receipts.clear(); clearInterval(poll); $('workspace').hidden = true; $('identity').hidden = true; $('login-panel').hidden = false;
});
