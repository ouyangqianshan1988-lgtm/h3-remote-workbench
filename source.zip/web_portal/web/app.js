'use strict';
let token = '';
let poll;
let downloading = false;
const receipts = new Map();
const $ = id => document.getElementById(id);
const base = (window.PORTAL_API || (['localhost', '127.0.0.1'].includes(location.hostname) ? location.origin : '')).replace(/\/$/, '');
async function api(path, options = {}) {
  if (!base) throw new Error('远程工作站尚未连接，请联系管理员。');
  let response;
  try {
    response = await fetch(base + path, {cache: 'no-store', ...options, headers: {...(options.body instanceof FormData ? {} : {'Content-Type': 'application/json'}), ...(token ? {'Authorization': 'Bearer ' + token} : {}), ...options.headers}});
  } catch (_) { throw new Error('无法连接工作站，请确认工作站已启动。'); }
  const data = await response.json();
  if (!response.ok) throw new Error(data.error || '请求失败');
  return data;
}
async function refresh() {
  try {
    const data = await api('/api/tasks'); $('service-message').textContent = data.message;
    $('submit-button').disabled = !data.accepting_tasks || data.tasks.some(t => ['uploading','queued','running','ready','downloading'].includes(t.state));
    if (!downloading) renderTasks(data.tasks);
  }
  catch (error) { $('service-message').textContent = error.message; }
}
$('login-form').addEventListener('submit', async event => {
  event.preventDefault(); $('login-button').disabled = true; $('login-message').textContent = '';
  try {
    const result = await api('/api/login', {method: 'POST', body: JSON.stringify({username: $('username-input').value.trim(), password: $('password-input').value})});
    token = result.token; $('password-input').value = ''; $('username').textContent = result.username;
    $('login-panel').hidden = true; $('workspace').hidden = false; $('identity').hidden = false;
    await refresh(); poll = setInterval(refresh, 5000);
  } catch (error) { $('login-message').textContent = error.message; }
  finally { $('login-button').disabled = false; }
});
function renderTasks(tasks) {
  const container = $('tasks'); container.replaceChildren();
  if (!tasks.length) {
    const empty = document.createElement('div'); empty.className = 'empty';
    const title = document.createElement('h2'); title.textContent = '暂无运行任务';
    const subtitle = document.createElement('p'); subtitle.textContent = '提交后在这里查看状态并下载结果。';
    empty.append(title, subtitle); container.append(empty); return;
  }
  for (const task of tasks) {
    const row = document.createElement('article'); row.className = 'task-row';
    const body = document.createElement('div'); const name = document.createElement('h2');
    name.textContent = '任务 ' + task.id.slice(0, 8);
    const status = document.createElement('p'); status.textContent = task.message;
    body.append(name, status); row.append(body);
    if (task.state === 'ready') {
      const button = document.createElement('button'); button.className = 'download';
      button.textContent = receipts.has(task.id) ? '已保存，清理工作站副本' : '下载视频';
      button.onclick = () => receipts.has(task.id) ? acknowledge(task.id, receipts.get(task.id)) : download(task.id);
      row.append(button);
    }
    if (['ready','queued','failed'].includes(task.state)) {
      const cancel = document.createElement('button'); cancel.className = 'quiet'; cancel.textContent = '放弃并清理';
      cancel.onclick = async () => {
        if (!confirm('放弃该任务并删除工作站上的临时文件？')) return;
        try { await api('/api/tasks/' + task.id, {method:'DELETE'}); await refresh(); }
        catch(error) { $('task-message').textContent=error.message; }
      }; row.append(cancel);
    }
    container.append(row);
  }
}
async function acknowledge(id, receipt) {
  try {
    await api('/api/tasks/' + id + '/downloaded', {method:'POST',body:JSON.stringify({receipt})});
    receipts.delete(id); $('task-message').textContent = '下载完成，工作站上的输入和结果已删除。'; await refresh();
  } catch(error) { receipts.set(id,receipt); $('task-message').textContent = '文件已保存，但清理确认失败。请点击任务旁的清理按钮重试。'; }
}
async function download(id) {
  let writable;
  downloading = true;
  try {
    if (window.showSaveFilePicker) {
      const handle = await window.showSaveFilePicker({suggestedName:'H3-result.mp4',types:[{description:'MP4视频',accept:{'video/mp4':['.mp4']}}]});
      writable = await handle.createWritable();
    }
    const response = await fetch(base + '/api/tasks/' + id + '/download', {cache:'no-store',headers:{Authorization:'Bearer '+token}});
    if (!response.ok) throw new Error('下载失败，请重试。');
    const receipt = response.headers.get('X-Download-Receipt');
    if (writable) {
      const reader = response.body.getReader(); let received=0;
      while (true) { const {value,done}=await reader.read(); if(done) break; received+=value.byteLength; await writable.write(value); }
      if (received !== Number(response.headers.get('Content-Length'))) throw new Error('文件传输未完成，请重试。');
      await writable.close(); writable=null;
      await acknowledge(id,receipt);
    } else {
      const blob = await response.blob();
      const url = URL.createObjectURL(blob); const a = document.createElement('a'); a.href=url;a.download='H3-result.mp4';a.click();
      setTimeout(()=>URL.revokeObjectURL(url),60000);
      receipts.set(id,receipt);
      $('task-message').textContent='浏览器已接收文件。确认下载已保存后，点击“已保存，清理工作站副本”。';
    }
  } catch(error) {
    if(writable) await writable.abort().catch(()=>{});
    if(error.name!=='AbortError') $('task-message').textContent=error.message;
  } finally { downloading=false; await refresh(); }
}
$('task-form').addEventListener('submit',async event=>{
  event.preventDefault(); $('submit-button').disabled=true; $('task-message').textContent='正在上传…';
  try {
    const data=new FormData($('task-form'));
    await api('/api/tasks',{method:'POST',body:data});
    $('task-form').reset(); $('task-message').textContent='任务已提交，输入内容已从表单清空。'; await refresh();
  } catch(error) { $('task-message').textContent=error.message; $('submit-button').disabled=false; }
});
if (document.modelContext?.registerTool) {
  document.modelContext.registerTool({name:'get_my_task_status',description:'读取当前登录账号的任务状态，不返回素材、提示词或结果。',inputSchema:{type:'object',properties:{},additionalProperties:false},annotations:{readOnlyHint:true},execute:async()=>{const data=await api('/api/tasks');await refresh();return {tasks:data.tasks};}});
}
$('logout').addEventListener('click', async () => {
  try { await api('/api/logout', {method: 'POST'}); } catch (_) {}
  token = ''; clearInterval(poll); $('workspace').hidden = true; $('identity').hidden = true; $('login-panel').hidden = false;
});
