const fs = require('node:fs'), vm = require('node:vm'), assert = require('node:assert/strict');
const app = fs.readFileSync(__dirname+'/web/app.js','utf8');
const code = app.slice(app.indexOf('async function saveAuthenticatedVideo'),app.indexOf('async function acknowledge'));
(async()=>{
  for(const type of ['application/octet-stream','text/html']) {
    let written=0, closed=false, aborted=false, requested;
    const context=vm.createContext({token:'owner-session',base:'https://gateway.example',downloading:false,
      URL, Uint8Array, $:()=>({textContent:''}), refresh:async()=>{},
      window:{showSaveFilePicker:async()=>({createWritable:async()=>({
        write:async value=>{written+=value.byteLength},close:async()=>{closed=true},abort:async()=>{aborted=true}
      })})},
      fetch:async(url,options)=>{requested={url,options};let count=0;return {ok:true,
        headers:{get:name=>name==='Content-Type'?type:'3'},body:{getReader:()=>({read:async()=>count++?{done:true}:{done:false,value:new Uint8Array([1,2,3])}})}}}
    });
    vm.runInContext(code,context);
    await context.saveAuthenticatedVideo('job-owner',{path:'/files/job-owner/202611100129.mp4?ticket=opaque'});
    assert.equal(requested.options.headers.Authorization,'Bearer owner-session');
    assert.equal(requested.url,'https://gateway.example/api/tasks/job-owner/download');
    assert.equal(written,type==='text/html'?0:3);
    assert.equal(closed,type!=='text/html');assert.equal(aborted,type==='text/html');
    assert.equal(context.downloading,false);
  }
  console.log('PASS: owner-authenticated streaming saves video; HTML is rejected before writing');
})().catch(e=>{console.error(e);process.exitCode=1});
