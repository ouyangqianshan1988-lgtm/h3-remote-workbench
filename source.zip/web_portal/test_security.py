import hashlib
import json
import secrets
import sys
import tempfile
import time
import unittest
from pathlib import Path
from unittest.mock import patch, MagicMock, AsyncMock
from aiohttp import FormData

sys.path.insert(0, str(Path(__file__).resolve().parent))
from aiohttp.test_utils import AioHTTPTestCase
import server
import engine


class SecurityTests(AioHTTPTestCase):
    async def get_application(self):
        self.temp = tempfile.TemporaryDirectory(dir=server.ROOT / 'private')
        root = Path(self.temp.name)
        self.patches = [patch.object(engine, 'RUNTIME', root), patch.object(server, 'RUNTIME', root),
                        patch.object(server, 'USER_FILE', root / 'users.json'),
                        patch.object(server, 'ENGINE', engine.Engine())]
        for p in self.patches:
            p.start()
        for part in ('input', 'output'):
            (root / part).mkdir()
        self.password = secrets.token_urlsafe(18)
        salt = secrets.token_bytes(32)
        record = dict(salt=salt.hex(), password_hash=hashlib.scrypt(self.password.encode(),salt=salt,n=16384,r=8,p=1).hex(),enabled=True,archive=False)
        server.USER_FILE.write_text(json.dumps({'alice':record,'bob':record}))
        server.SESSIONS.clear()
        server.ATTEMPTS.clear()
        return server.make_app()

    async def asyncTearDown(self):
        await super().asyncTearDown()
        for p in reversed(self.patches):
            p.stop()
        self.temp.cleanup()

    async def auth(self, username):
        response = await self.client.post('/api/login', json={'username':username,'password':self.password})
        self.assertEqual(response.status,200)
        return {'Authorization':'Bearer '+(await response.json())['token']}

    async def test_isolation_and_confirmed_cleanup(self):
        alice, bob = await self.auth('alice'), await self.auth('bob')
        job=server.ENGINE.new_job('alice')
        output=engine.RUNTIME/'output'/job['id']/'result.mp4'
        output.write_bytes(b'test-video')
        job.update(state='ready',output=output)
        base='/api/tasks/'+job['id']
        r=await self.client.get(base+'/download',headers=bob);self.assertEqual(r.status,404)
        r=await self.client.delete(base,headers=bob);self.assertEqual(r.status,404)
        r=await self.client.post(base+'/downloaded',headers=alice,json={'receipt':job['receipt'],'confirmed_saved':True});self.assertEqual(r.status,409)
        r=await self.client.get('/api/tasks',headers=bob);self.assertEqual((await r.json())['tasks'],[])
        r=await self.client.get(base+'/download',headers=alice);self.assertEqual(await r.read(),b'test-video')
        self.assertTrue(output.exists())
        r=await self.client.post(base+'/downloaded',headers=alice,json={'receipt':job['receipt'],'confirmed_saved':True});self.assertEqual(r.status,200)
        self.assertFalse(output.exists())
        r=await self.client.get(base+'/download',headers=alice);self.assertEqual(r.status,409)

    async def test_native_download_ranges_and_explicit_cleanup(self):
        alice, bob = await self.auth('alice'), await self.auth('bob')
        job = server.ENGINE.new_job('alice')
        output = engine.RUNTIME / 'output' / job['id'] / 'result.mp4'
        content = b'native-video-range-test' * 100
        output.write_bytes(content)
        job.update(state='ready', output=output)
        base = '/api/tasks/' + job['id']
        r = await self.client.post(base + '/download-link', headers=bob)
        self.assertEqual(r.status, 404)
        r = await self.client.post(base + '/download-link', headers=alice)
        ticket = await r.json(); self.assertEqual(r.status, 200)
        path = ticket['path']
        r = await self.client.get(path, headers=bob)
        self.assertEqual(r.status, 404)
        r = await self.client.head(path, headers=bob)
        self.assertEqual(r.status, 404)
        self.client.session.cookie_jar.clear()
        r = await self.client.get(path)
        self.assertEqual(r.status, 401)
        self.assertIn('application/json', r.headers['Content-Type'])
        self.assertNotEqual(await r.read(), content)
        r = await self.client.get(path, headers={'Cookie': server.DOWNLOAD_COOKIE+'='+alice['Authorization'][7:]})
        self.assertEqual(r.status, 200); self.assertEqual(await r.read(), content)
        r = await self.client.get(path.replace('ticket=', 'ticket=wrong'))
        self.assertEqual(r.status, 404)
        r = await self.client.get(path, headers={**alice, 'Range':'bytes=100-199'})
        self.assertEqual(r.status, 206); self.assertEqual(await r.read(), content[100:200])
        self.assertIn('attachment;', r.headers['Content-Disposition'])
        r = await self.client.get(path, headers=alice)
        self.assertEqual(await r.read(), content)
        self.assertEqual(job['state'], 'ready'); self.assertTrue(output.exists())
        r = await self.client.post(base + '/downloaded', headers=alice, json={'receipt':ticket['receipt']})
        self.assertEqual(r.status, 409); self.assertTrue(output.exists())
        job['download_expires'] = time.time() - 1
        r = await self.client.get(path); self.assertEqual(r.status, 404)
        self.assertTrue(output.exists())
        r = await self.client.post(base + '/downloaded', headers=alice,
                                  json={'receipt':ticket['receipt'], 'confirmed_saved':True})
        self.assertEqual(r.status, 200); self.assertFalse(output.exists())
        r = await self.client.get(path); self.assertEqual(r.status, 404)

    async def test_logout_revokes_native_links_and_expired_session_denies_bytes(self):
        alice = await self.auth('alice')
        job = server.ENGINE.new_job('alice')
        output = engine.RUNTIME / 'output' / job['id'] / 'result.mp4'
        output.write_bytes(b'private-alice-video')
        job.update(state='ready', output=output)
        r = await self.client.post('/api/tasks/'+job['id']+'/download-link', headers=alice)
        path = (await r.json())['path']
        token = alice['Authorization'][7:]
        server.SESSIONS[token]['expires'] = time.monotonic()-1
        r = await self.client.get(path, headers=alice)
        self.assertEqual(r.status,401)
        server.SESSIONS[token]['expires'] = time.monotonic()+3600
        r = await self.client.post('/api/logout', headers=alice)
        self.assertEqual(r.status,200)
        r = await self.client.get(path, headers={'Cookie':server.DOWNLOAD_COOKIE+'='+token})
        self.assertEqual(r.status,404)
        self.assertTrue(output.is_file())

    async def test_cross_site_native_post_authenticates_before_download(self):
        alice, bob = await self.auth('alice'), await self.auth('bob')
        job = server.ENGINE.new_job('alice')
        output = engine.RUNTIME / 'output' / job['id'] / 'result.mp4'
        content = b'mp4-private-content' * 100
        output.write_bytes(content); job.update(state='ready', output=output)
        r = await self.client.post('/api/tasks/'+job['id']+'/download-link', headers=alice)
        path = (await r.json())['path']
        self.client.session.cookie_jar.clear()
        r = await self.client.post(path, data={'session':bob['Authorization'][7:]}, allow_redirects=False)
        self.assertEqual(r.status,404)
        r = await self.client.post(path, data={'session':alice['Authorization'][7:]}, allow_redirects=False)
        self.assertEqual(r.status,303)
        self.assertNotIn(alice['Authorization'][7:], r.headers['Location'])
        self.assertTrue(r.cookies[server.DOWNLOAD_COOKIE]['httponly'])
        cookie = server.DOWNLOAD_COOKIE+'='+r.cookies[server.DOWNLOAD_COOKIE].value
        r = await self.client.get(path, headers={'Cookie':cookie,'Range':'bytes=0-99'})
        self.assertEqual(r.status,206); self.assertEqual(await r.read(),content[:100])
        self.assertIn('.mp4', r.headers['Content-Disposition'])
        self.assertNotIn('text/html',r.headers['Content-Type'])
        self.assertTrue(output.exists())

    async def test_explicit_ready_handoff_preserves_ownership_and_file(self):
        import json
        job = server.ENGINE.new_job('alice')
        directory = engine.RUNTIME / 'output' / job['id']
        output = directory / 'result_00001-audio.mp4'
        output.write_bytes(b'ready-result')
        snapshot = engine.RUNTIME / 'ready.json'
        snapshot.write_text(json.dumps([dict(id=job['id'],owner='alice',state='ready',created=time.time(),filename='202611100129.mp4',archive=False)]))
        recovered = engine.Engine()
        kept = recovered.restore_ready_jobs(snapshot)
        self.assertEqual(kept,{job['id']})
        self.assertEqual(recovered.jobs[job['id']]['owner'],'alice')
        self.assertEqual(recovered.jobs[job['id']]['output'].read_bytes(), b'ready-result')
        self.assertNotIn('download_ticket',recovered.jobs[job['id']])

    async def test_unclaimed_result_does_not_expire(self):
        import asyncio
        job = server.ENGINE.new_job('alice')
        output = engine.RUNTIME / 'output' / job['id'] / 'result.mp4'
        output.write_bytes(b'unclaimed')
        job.update(state='ready', output=output, updated=time.time()-7200)
        with patch.object(engine.asyncio, 'sleep', new=AsyncMock(side_effect=[None, asyncio.CancelledError()])):
            with self.assertRaises(asyncio.CancelledError):
                await server.ENGINE.expire()
        self.assertEqual(job['state'], 'ready'); self.assertTrue(output.exists())

    async def test_login_cors_and_private_paths(self):
        r=await self.client.get('/api/tasks');self.assertEqual(r.status,401)
        r=await self.client.post('/api/login',json=[]);self.assertEqual(r.status,400)
        r=await self.client.post('/api/login',json={'username':'alice','password':'wrong'});self.assertEqual(r.status,401)
        r=await self.client.post('/api/login',json={},headers={'Origin':'https://untrusted.example'});self.assertEqual(r.status,403)
        r=await self.client.get('/private/users.json');self.assertEqual(r.status,404)
        headers=await self.auth('alice')
        await self.client.post('/api/logout',headers=headers)
        r=await self.client.get('/api/tasks',headers=headers);self.assertEqual(r.status,401)

    async def test_cleanup_cannot_escape_runtime(self):
        with self.assertRaises(ValueError):engine.erase(engine.RUNTIME.parent)
        with self.assertRaises(ValueError):engine.erase(engine.RUNTIME)

    async def test_failure_log_is_redacted_and_bounded(self):
        log = Path(self.temp.name) / 'failure_logs' / 'failures.jsonl'
        job = dict(id='12345678-1234-1234-1234-123456789012', owner='secret-account',
                   recipe={'prompt':'private prompt text', 'images':['C:/private/reference.png'],
                           'model':'dasiwa-turbo-v3', 'resolution':'768p', 'seconds':12,
                           'orientation':'landscape'})
        with patch.object(engine, 'FAILURE_LOG', log):
            server.ENGINE.record_failure(job, 'comfy_execution_failed', 'poll', 1, False)
            record = json.loads(log.read_text(encoding='utf-8').strip())
            serialized = log.read_text(encoding='utf-8')
            for private_value in ('private prompt text', 'reference.png', 'secret-account', '12345678-1234'):
                self.assertNotIn(private_value, serialized)
            self.assertEqual(record['code'], 'comfy_execution_failed')
            self.assertEqual(record['stage'], 'poll')
            self.assertEqual(record['model'], 'dasiwa-turbo-v3')
            self.assertEqual(record['resolution'], '768p')
            self.assertEqual(record['seconds'], 12)
            self.assertEqual(record['worker_exit_code'], 1)
            self.assertLessEqual(log.stat().st_size, engine.FAILURE_LOG_MAX_BYTES)

    async def test_failure_log_limits_retention(self):
        log = Path(self.temp.name) / 'failure_logs' / 'failures.jsonl'
        with patch.object(engine, 'FAILURE_LOG', log):
            for i in range(engine.FAILURE_LOG_MAX_RECORDS + 5):
                server.ENGINE.record_failure({'id': str(i), '_failure_meta': {}}, 'internal_error', 'generation')
            rows = [json.loads(line) for line in log.read_text(encoding='utf-8').splitlines()]
            self.assertEqual(len(rows), engine.FAILURE_LOG_MAX_RECORDS)
            self.assertEqual(rows[0]['task'], '5')

    async def test_archive_survives_download_cleanup(self):
        with patch.object(engine, 'ARCHIVE_ROOT', engine.RUNTIME / 'archive'):
            job = server.ENGINE.new_job('alice', archive=True)
            output = engine.RUNTIME / 'output' / job['id'] / 'result.mp4'
            output.write_bytes(b'archive-test')
            job.update(state='ready', output=output)
            server.ENGINE.archive_output(job)
            archived = engine.ARCHIVE_ROOT / 'alice' / Path(job['filename']).stem / job['filename']
            self.assertFalse(output.exists())
            self.assertEqual(job['output'], archived)
            server.ENGINE.remove(job)
            self.assertEqual(archived.read_bytes(), b'archive-test')
            self.assertFalse(output.exists())
            with self.assertRaises(ValueError): engine.archive_directory('../escape')

    async def test_receipt_order_precedes_upload_completion(self):
        first = server.ENGINE.new_job('alice')
        second = server.ENGINE.new_job('bob')
        second['uploaded'].set()
        self.assertIs(await server.ENGINE.queue.get(), first)
        self.assertFalse(first['uploaded'].is_set())
        self.assertIs(await server.ENGINE.queue.get(), second)

    async def test_completion_filename_and_collision(self):
        with patch.object(engine, 'ARCHIVE_ROOT', engine.RUNTIME / 'archive'):
            completed = engine.datetime(2026, 9, 27, 20, 44, tzinfo=engine.timezone(engine.timedelta(hours=8))).timestamp()
            names = []
            for _ in range(2):
                job = server.ENGINE.new_job('alice', archive=True)
                output = engine.RUNTIME / 'output' / job['id'] / 'result.mp4'
                output.write_bytes(b'video')
                inputs = engine.RUNTIME / 'input' / job['id']
                (inputs / 'prompt.txt').write_text('测试提示词', encoding='utf-8')
                (inputs / '1.png').write_bytes(b'reference-image')
                (inputs / 'ref_video_1.mp4').write_bytes(b'reference-video')
                (inputs / 'ref_audio_1.wav').write_bytes(b'reference-audio')
                job.update(state='ready', output=output, completed=completed)
                server.ENGINE.archive_output(job)
                names.append(job['filename'])
                server.ENGINE.archive_output(job)
                server.ENGINE.remove(job)
            self.assertEqual(names, ['202609272044.mp4', '202609272044_2.mp4'])
            saved = engine.ARCHIVE_ROOT / 'alice' / '202609272044'
            self.assertEqual((saved / '202609272044.txt').read_text(encoding='utf-8'), '测试提示词')
            self.assertEqual((saved / 'picture1.png').read_bytes(), b'reference-image')
            self.assertEqual((saved / 'video1.mp4').read_bytes(), b'reference-video')
            self.assertEqual((saved / 'audio1.wav').read_bytes(), b'reference-audio')
            results = [path for path in (engine.ARCHIVE_ROOT / 'alice').glob('*/*.mp4')
                       if path.name[:12].isdigit()]
            self.assertEqual(len(results), 2)

    async def test_duration_limit(self):
        headers = await self.auth('alice')
        server.ENGINE.ready = True
        server.ENGINE.client = MagicMock()
        response = server.ENGINE.client.get.return_value.__aenter__.return_value
        response.json = AsyncMock(return_value={'queue_running':[], 'queue_pending':[]})
        for resolution, seconds, code in [('720p','30',202),('720p','30.1',400),('720p','nan',400),('1080p','15',202),('1080p','15.1',202),('1080p','30',202),('1080p','30.1',400),('4k','1',400)]:
            form = FormData(default_to_multipart=True)
            form.add_field('prompt','A landscape')
            form.add_field('seconds',seconds)
            form.add_field('resolution',resolution)
            r = await self.client.post('/api/tasks',data=form,headers=headers)
            self.assertEqual(r.status,code,await r.text())
            if code == 202:
                job=server.ENGINE.jobs[(await r.json())['id']]
                self.assertEqual(job['recipe']['seconds'],float(seconds))
                self.assertEqual(job['recipe']['model'],'yz-goldfish')
                self.assertEqual(job['recipe']['aspect_ratio'],'16:9')
                server.ENGINE.remove(job)

    async def test_subaccounts_can_select_only_the_published_workflows(self):
        headers = await self.auth('alice')
        r = await self.client.get('/api/tasks',headers=headers)
        data = await r.json()
        models = data['models']
        self.assertTrue(data['media_reference_available'])
        self.assertTrue(data['aspect_ratio_available'])
        self.assertEqual([m['id'] for m in models], ['yz-goldfish','dasiwa-turbo-v3'])
        self.assertTrue(all(m['available'] for m in models))
        self.assertEqual([m['id'] for m in server.allowed_models('test')], ['yz-goldfish','dasiwa-turbo-v3'])
        server.ENGINE.ready = True
        server.ENGINE.client = MagicMock()
        response = server.ENGINE.client.get.return_value.__aenter__.return_value
        response.json = AsyncMock(return_value={'queue_running':[], 'queue_pending':[]})
        for model in ('original','h3-quality','h3-single','dasiwa-v2'):
            form = FormData(default_to_multipart=True)
            form.add_field('prompt','Test')
            form.add_field('model',model)
            r = await self.client.post('/api/tasks',data=form,headers=headers)
            self.assertEqual(r.status,400,model)
            self.assertEqual(server.ENGINE.jobs,{})
        for model in ('dasiwa-turbo-v3','yz-goldfish'):
            form = FormData(default_to_multipart=True)
            form.add_field('prompt','Test')
            form.add_field('seconds','1')
            form.add_field('model',model)
            r = await self.client.post('/api/tasks',data=form,headers=headers)
            self.assertEqual(r.status,202,await r.text())
            job = server.ENGINE.jobs[(await r.json())['id']]
            self.assertEqual(job['recipe']['model'],model)
            server.ENGINE.remove(job)

    async def test_multimedia_upload_is_connected_to_yz_reference_inputs(self):
        headers = await self.auth('alice')
        server.ENGINE.ready = True
        server.ENGINE.client = MagicMock()
        response = server.ENGINE.client.get.return_value.__aenter__.return_value
        response.json = AsyncMock(return_value={'queue_running':[], 'queue_pending':[]})
        form = FormData(default_to_multipart=True)
        form.add_field('prompt', 'Use Video 1 and Audio 1 as references.')
        form.add_field('aspect_ratio', '1:1')
        form.add_field('videos', b'video-bytes', filename='clip.mp4', content_type='video/mp4')
        form.add_field('audios', b'audio-bytes', filename='voice.wav', content_type='audio/wav')
        r = await self.client.post('/api/tasks', data=form, headers=headers)
        self.assertEqual(r.status, 202, await r.text())
        job = server.ENGINE.jobs[(await r.json())['id']]
        input_dir = engine.RUNTIME / 'input' / job['id']
        self.assertEqual((input_dir / 'ref_video_1.mp4').read_bytes(), b'video-bytes')
        self.assertEqual((input_dir / 'ref_audio_1.wav').read_bytes(), b'audio-bytes')
        graph = server.ENGINE.prompt({'id': job['id'], 'recipe': job['recipe']})
        self.assertEqual((graph['265']['inputs']['width'], graph['265']['inputs']['height']), (960, 960))
        self.assertEqual(graph['265']['inputs']['ref_videos.ref_video_0'], ['9101', 0])
        self.assertEqual(graph['265']['inputs']['ref_video_audios.ref_video_audio_0'], ['9101', 2])
        self.assertEqual(graph['265']['inputs']['ref_audios.ref_audio_0'], ['9201', 0])
        self.assertEqual(graph['9101']['inputs']['video'], str((engine.RUNTIME / 'input' / job['recipe']['videos'][0]).resolve()))
        self.assertEqual(graph['9101']['inputs']['format'], 'H3')
        self.assertEqual(graph['9101']['inputs']['frame_load_cap'], 360)
        self.assertEqual(graph['9201']['inputs']['duration'], 30)
        self.assertEqual(graph['9201']['inputs']['audio_file'], str((engine.RUNTIME / 'input' / job['recipe']['audios'][0]).resolve()))
        server.ENGINE.remove(job)

    async def test_media_upload_rejects_unsupported_extensions_and_duplicate_media(self):
        headers = await self.auth('alice')
        server.ENGINE.ready = True
        server.ENGINE.client = MagicMock()
        response = server.ENGINE.client.get.return_value.__aenter__.return_value
        response.json = AsyncMock(return_value={'queue_running':[], 'queue_pending':[]})
        form = FormData(default_to_multipart=True)
        form.add_field('prompt', 'Test')
        form.add_field('videos', b'not-allowed', filename='clip.exe', content_type='application/octet-stream')
        r = await self.client.post('/api/tasks', data=form, headers=headers)
        self.assertEqual(r.status, 400)
        self.assertEqual(server.ENGINE.jobs, {})
        form = FormData(default_to_multipart=True)
        form.add_field('prompt', 'Test')
        form.add_field('audios', b'first', filename='one.mp3', content_type='audio/mpeg')
        form.add_field('audios', b'second', filename='two.mp3', content_type='audio/mpeg')
        r = await self.client.post('/api/tasks', data=form, headers=headers)
        self.assertEqual(r.status, 400)
        self.assertEqual(server.ENGINE.jobs, {})
    async def test_lora_checkbox_is_restricted_to_dasiwa_turbo_and_installed_lora(self):
        headers = await self.auth('alice')
        server.ENGINE.ready = True
        server.ENGINE.client = MagicMock()
        response = server.ENGINE.client.get.return_value.__aenter__.return_value
        response.json = AsyncMock(return_value={'queue_running':[], 'queue_pending':[]})
        form = FormData(default_to_multipart=True)
        form.add_field('prompt','Test')
        form.add_field('model','yz-goldfish')
        form.add_field('use_lora','on')
        r = await self.client.post('/api/tasks',data=form,headers=headers)
        self.assertEqual(r.status,400)
        self.assertEqual(server.ENGINE.jobs,{})
        form = FormData(default_to_multipart=True)
        form.add_field('prompt','Test')
        form.add_field('model','dasiwa-turbo-v3')
        form.add_field('use_lora','on')
        form.add_field('lora_strength','0.37')
        with patch.object(server, 'dasiwa_turbo_lora', return_value={'filename':'test.safetensors','strength':1.0}):
            r = await self.client.post('/api/tasks',data=form,headers=headers)
        self.assertEqual(r.status,202,await r.text())
        job = server.ENGINE.jobs[(await r.json())['id']]
        self.assertTrue(job['recipe']['use_lora'])
        self.assertEqual(job['recipe']['lora_strength'], 0.37)
        server.ENGINE.remove(job)
        server.ENGINE.jobs.clear()
        for invalid_strength in ('-0.01', '1.01', 'NaN', 'Infinity', 'not-a-number'):
            form = FormData(default_to_multipart=True)
            form.add_field('prompt','Test')
            form.add_field('model','dasiwa-turbo-v3')
            form.add_field('lora_strength',invalid_strength)
            r = await self.client.post('/api/tasks',data=form,headers=headers)
            self.assertEqual(r.status,400,invalid_strength)
            self.assertEqual(server.ENGINE.jobs,{})
        form = FormData(default_to_multipart=True)
        form.add_field('prompt','Test')
        form.add_field('model','dasiwa-turbo-v3')
        form.add_field('use_lora','on')
        with patch.object(server, 'dasiwa_turbo_lora', return_value=None):
            r = await self.client.post('/api/tasks',data=form,headers=headers)
        self.assertEqual(r.status,400)
        self.assertEqual(server.ENGINE.jobs,{})

    async def test_full_hd_dimensions(self):
        for orientation, expected in [('landscape',(1920,1088)),('portrait',(1088,1920))]:
            recipe = dict(prompt='Test', seconds=1, orientation=orientation, resolution='1080p', images=[], seed=42, model='yz-goldfish')
            graph = server.ENGINE.prompt({'id':'test','recipe':recipe})
            inputs = graph['265']['inputs']
            self.assertEqual((inputs['width'],inputs['height']),expected)
            self.assertEqual(inputs['length'],39)

    async def test_common_aspect_ratio_dimensions_are_aligned_and_bounded(self):
        for resolution, max_edge in [('720p',1280), ('768p',1344), ('1080p',1920)]:
            for ratio in engine.ASPECT_RATIOS:
                width, height = engine.dimensions_for(resolution, ratio)
                self.assertGreaterEqual(width, 32)
                self.assertGreaterEqual(height, 32)
                self.assertEqual(width % 32, 0)
                self.assertEqual(height % 32, 0)
                self.assertLessEqual(max(width, height), max_edge)
        with self.assertRaises(ValueError):
            engine.dimensions_for('720p', '7:5')
    async def test_text_only_and_empty_browser_file(self):
        headers = await self.auth('alice')
        server.ENGINE.ready = True
        server.ENGINE.client = MagicMock()
        response = server.ENGINE.client.get.return_value.__aenter__.return_value
        response.json = AsyncMock(return_value={'queue_running':[], 'queue_pending':[]})
        for blank_file in (False, True):
            form = FormData(default_to_multipart=True)
            form.add_field('prompt', 'An orange ball rolling on grass.')
            if blank_file:
                form.add_field('images', b'', filename='', content_type='application/octet-stream')
            r = await self.client.post('/api/tasks',data=form,headers=headers)
            self.assertEqual(r.status,202,await r.text())
            job = server.ENGINE.jobs[(await r.json())['id']]
            self.assertEqual(job['recipe']['images'],[])
            server.ENGINE.remove(job)

    async def test_video_output_prefers_audio_muxed_final_file(self):
        output = engine.RUNTIME / 'output' / 'vhs-test'
        output.mkdir(parents=True, exist_ok=True)
        silent = output / 'result_00001.mp4'
        muxed = output / 'result_00001-audio.mp4'
        silent.write_bytes(b'silent-video')
        muxed.write_bytes(b'video-with-audio')
        self.assertEqual(engine.select_video_output(output), muxed)
        muxed.unlink()
        self.assertEqual(engine.select_video_output(output), silent)
        silent.unlink()
        output.rmdir()

    async def test_model_selection_preserves_the_two_published_graphs(self):
        job_id='12345678-1234-1234-1234-123456789abc'
        recipe = dict(prompt='Test prompt', seconds=1, orientation='landscape', images=['test/1.png','test/2.png'], seed=42, model='dasiwa-turbo-v3')
        turbo = server.ENGINE.prompt({'id':job_id, 'recipe':dict(recipe)})
        self.assertEqual(turbo['261']['inputs']['steps'], 8)
        self.assertEqual(turbo['397']['inputs']['transition_step'], 6)
        self.assertEqual(turbo['333']['inputs'], dict(model=['332',0], shift_video=12.0, shift_audio=3.0000000000000004))
        self.assertEqual(turbo['192']['inputs']['unet_name'], engine.MODELS['dasiwa-turbo-v3'][1])
        self.assertNotIn('MiniMaxH3FiniteSegmentSampler', {n['class_type'] for n in turbo.values()})
        with patch.object(engine, 'dasiwa_turbo_lora', return_value={'filename':'test.safetensors','strength':0.8}):
            turbo_lora = server.ENGINE.prompt({'id':job_id, 'recipe':dict(recipe, use_lora=True, lora_strength=0.37)})
        self.assertEqual(turbo_lora['14']['inputs']['strength_model'], 0.37)
        self.assertEqual(turbo_lora['331']['inputs']['model'], ['14', 0])
        self.assertEqual(turbo['331']['inputs']['model'], ['192', 0])
        yz_recipe=dict(recipe, model='yz-goldfish', seconds=5.1666666667, resolution='768p')
        yz=server.ENGINE.prompt({'id':job_id, 'recipe':yz_recipe})
        self.assertEqual(yz['265']['inputs']['prompt'], 'Test prompt')
        self.assertEqual(yz['265']['inputs']['length'], 124)
        self.assertEqual((yz['265']['inputs']['width'],yz['265']['inputs']['height']), (1344,768))
        self.assertEqual(yz['265']['inputs']['ref_images.ref_image_0'], ['9001',0])
        self.assertEqual(yz['9001']['inputs']['image'], job_id+'/1.png')
        self.assertEqual(yz['364']['inputs']['filename_prefix'], job_id+'/result')
        self.assertEqual(yz['397']['inputs']['seed'], 42)
        for closed in ('original','h3-single','h3-quality','dasiwa-v2','../invalid'):
            with self.assertRaises(ValueError):
                server.ENGINE.prompt({'id':'test','recipe':dict(recipe, model=closed)})

    async def test_default_model_is_yz_goldfish(self):
        self.assertEqual(next(iter(engine.MODELS)), 'yz-goldfish')
        graph = server.ENGINE.prompt({'id':'test','recipe':dict(
            prompt='Default model', seconds=1, orientation='landscape', resolution='720p',
            images=[], seed=1)})
        self.assertEqual(graph['192']['inputs']['unet_name'], engine.MODELS['yz-goldfish'][1])

if __name__=='__main__':
    unittest.main()
