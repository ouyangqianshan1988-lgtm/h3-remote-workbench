import hashlib
import json
import secrets
import sys
import tempfile
import time
import unittest
from pathlib import Path
from unittest.mock import patch

sys.path.insert(0, str(Path(__file__).resolve().parent))
from aiohttp.test_utils import AioHTTPTestCase
import server
import engine


class SecurityTests(AioHTTPTestCase):
    async def get_application(self):
        self.temp = tempfile.TemporaryDirectory(dir=server.ROOT / 'private')
        root = Path(self.temp.name)
        self.patches = [patch.object(engine, 'RUNTIME', root), patch.object(server, 'RUNTIME', root),
                        patch.object(server, 'USER_FILE', root / 'users.json'),
                        patch.object(server, 'ENGINE', engine.Engine())]
        for p in self.patches:
            p.start()
        for part in ('input', 'output'):
            (root / part).mkdir()
        self.password = secrets.token_urlsafe(18)
        salt = secrets.token_bytes(32)
        record = dict(salt=salt.hex(), password_hash=hashlib.scrypt(self.password.encode(),salt=salt,n=16384,r=8,p=1).hex(),enabled=True)
        server.USER_FILE.write_text(json.dumps({'alice':record,'bob':record}))
        server.SESSIONS.clear()
        server.ATTEMPTS.clear()
        return server.make_app()

    async def asyncTearDown(self):
        await super().asyncTearDown()
        for p in reversed(self.patches):
            p.stop()
        self.temp.cleanup()

    async def auth(self, username):
        response = await self.client.post('/api/login', json={'username':username,'password':self.password})
        self.assertEqual(response.status,200)
        return {'Authorization':'Bearer '+(await response.json())['token']}

    async def test_isolation_and_confirmed_cleanup(self):
        alice, bob = await self.auth('alice'), await self.auth('bob')
        job=server.ENGINE.new_job('alice')
        output=engine.RUNTIME/'output'/job['id']/'result.mp4'
        output.write_bytes(b'test-video')
        job.update(state='ready',output=output)
        base='/api/tasks/'+job['id']
        r=await self.client.get(base+'/download',headers=bob);self.assertEqual(r.status,404)
        r=await self.client.delete(base,headers=bob);self.assertEqual(r.status,404)
        r=await self.client.post(base+'/downloaded',headers=alice,json={'receipt':job['receipt']});self.assertEqual(r.status,409)
        r=await self.client.get('/api/tasks',headers=bob);self.assertEqual((await r.json())['tasks'],[])
        r=await self.client.get(base+'/download',headers=alice);self.assertEqual(await r.read(),b'test-video')
        self.assertTrue(output.exists())
        r=await self.client.post(base+'/downloaded',headers=alice,json={'receipt':job['receipt']});self.assertEqual(r.status,200)
        self.assertFalse(output.exists())
        r=await self.client.get(base+'/download',headers=alice);self.assertEqual(r.status,409)

    async def test_login_cors_and_private_paths(self):
        r=await self.client.get('/api/tasks');self.assertEqual(r.status,401)
        r=await self.client.post('/api/login',json=[]);self.assertEqual(r.status,400)
        r=await self.client.post('/api/login',json={'username':'alice','password':'wrong'});self.assertEqual(r.status,401)
        r=await self.client.post('/api/login',json={},headers={'Origin':'https://untrusted.example'});self.assertEqual(r.status,403)
        r=await self.client.get('/private/users.json');self.assertEqual(r.status,404)
        headers=await self.auth('alice')
        await self.client.post('/api/logout',headers=headers)
        r=await self.client.get('/api/tasks',headers=headers);self.assertEqual(r.status,401)

    async def test_cleanup_cannot_escape_runtime(self):
        with self.assertRaises(ValueError):engine.erase(engine.RUNTIME.parent)
        with self.assertRaises(ValueError):engine.erase(engine.RUNTIME)


if __name__=='__main__':
    unittest.main()
