import hashlib
import json
import secrets
import sys
import tempfile
import time
import unittest
from pathlib import Path
from unittest.mock import patch, MagicMock, AsyncMock
from aiohttp import FormData

sys.path.insert(0, str(Path(__file__).resolve().parent))
from aiohttp.test_utils import AioHTTPTestCase
import server
import engine


class SecurityTests(AioHTTPTestCase):
    async def get_application(self):
        self.temp = tempfile.TemporaryDirectory(dir=server.ROOT / 'private')
        root = Path(self.temp.name)
        self.patches = [patch.object(engine, 'RUNTIME', root), patch.object(server, 'RUNTIME', root),
                        patch.object(server, 'USER_FILE', root / 'users.json'),
                        patch.object(server, 'ENGINE', engine.Engine())]
        for p in self.patches:
            p.start()
        for part in ('input', 'output'):
            (root / part).mkdir()
        self.password = secrets.token_urlsafe(18)
        salt = secrets.token_bytes(32)
        record = dict(salt=salt.hex(), password_hash=hashlib.scrypt(self.password.encode(),salt=salt,n=16384,r=8,p=1).hex(),enabled=True,archive=False)
        server.USER_FILE.write_text(json.dumps({'alice':record,'bob':record}))
        server.SESSIONS.clear()
        server.ATTEMPTS.clear()
        return server.make_app()

    async def asyncTearDown(self):
        await super().asyncTearDown()
        for p in reversed(self.patches):
            p.stop()
        self.temp.cleanup()

    async def auth(self, username):
        response = await self.client.post('/api/login', json={'username':username,'password':self.password})
        self.assertEqual(response.status,200)
        return {'Authorization':'Bearer '+(await response.json())['token']}

    async def test_isolation_and_confirmed_cleanup(self):
        alice, bob = await self.auth('alice'), await self.auth('bob')
        job=server.ENGINE.new_job('alice')
        output=engine.RUNTIME/'output'/job['id']/'result.mp4'
        output.write_bytes(b'test-video')
        job.update(state='ready',output=output)
        base='/api/tasks/'+job['id']
        r=await self.client.get(base+'/download',headers=bob);self.assertEqual(r.status,404)
        r=await self.client.delete(base,headers=bob);self.assertEqual(r.status,404)
        r=await self.client.post(base+'/downloaded',headers=alice,json={'receipt':job['receipt']});self.assertEqual(r.status,409)
        r=await self.client.get('/api/tasks',headers=bob);self.assertEqual((await r.json())['tasks'],[])
        r=await self.client.get(base+'/download',headers=alice);self.assertEqual(await r.read(),b'test-video')
        self.assertTrue(output.exists())
        r=await self.client.post(base+'/downloaded',headers=alice,json={'receipt':job['receipt']});self.assertEqual(r.status,200)
        self.assertFalse(output.exists())
        r=await self.client.get(base+'/download',headers=alice);self.assertEqual(r.status,409)

    async def test_login_cors_and_private_paths(self):
        r=await self.client.get('/api/tasks');self.assertEqual(r.status,401)
        r=await self.client.post('/api/login',json=[]);self.assertEqual(r.status,400)
        r=await self.client.post('/api/login',json={'username':'alice','password':'wrong'});self.assertEqual(r.status,401)
        r=await self.client.post('/api/login',json={},headers={'Origin':'https://untrusted.example'});self.assertEqual(r.status,403)
        r=await self.client.get('/private/users.json');self.assertEqual(r.status,404)
        headers=await self.auth('alice')
        await self.client.post('/api/logout',headers=headers)
        r=await self.client.get('/api/tasks',headers=headers);self.assertEqual(r.status,401)

    async def test_cleanup_cannot_escape_runtime(self):
        with self.assertRaises(ValueError):engine.erase(engine.RUNTIME.parent)
        with self.assertRaises(ValueError):engine.erase(engine.RUNTIME)

    async def test_archive_survives_download_cleanup(self):
        with patch.object(engine, 'ARCHIVE_ROOT', engine.RUNTIME / 'archive'):
            job = server.ENGINE.new_job('alice', archive=True)
            output = engine.RUNTIME / 'output' / job['id'] / 'result.mp4'
            output.write_bytes(b'archive-test')
            job.update(state='ready', output=output)
            server.ENGINE.archive_output(job)
            archived = engine.ARCHIVE_ROOT / 'alice' / (job['id'] + '.mp4')
            server.ENGINE.remove(job)
            self.assertEqual(archived.read_bytes(), b'archive-test')
            self.assertFalse(output.exists())
            with self.assertRaises(ValueError): engine.archive_directory('../escape')

    async def test_receipt_order_precedes_upload_completion(self):
        first = server.ENGINE.new_job('alice')
        second = server.ENGINE.new_job('bob')
        second['uploaded'].set()
        self.assertIs(await server.ENGINE.queue.get(), first)
        self.assertFalse(first['uploaded'].is_set())
        self.assertIs(await server.ENGINE.queue.get(), second)

    async def test_duration_limit(self):
        headers = await self.auth('alice')
        server.ENGINE.ready = True
        server.ENGINE.client = MagicMock()
        response = server.ENGINE.client.get.return_value.__aenter__.return_value
        response.json = AsyncMock(return_value={'queue_running':[], 'queue_pending':[]})
        for seconds, code in [('30',202),('30.1',400),('nan',400)]:
            form = FormData(default_to_multipart=True)
            form.add_field('prompt','A landscape')
            form.add_field('seconds',seconds)
            r = await self.client.post('/api/tasks',data=form,headers=headers)
            self.assertEqual(r.status,code,await r.text())
            if code == 202:
                job=server.ENGINE.jobs[(await r.json())['id']]
                self.assertEqual(job['recipe']['seconds'],30)
                server.ENGINE.remove(job)

    async def test_text_only_and_empty_browser_file(self):
        headers = await self.auth('alice')
        server.ENGINE.ready = True
        server.ENGINE.client = MagicMock()
        response = server.ENGINE.client.get.return_value.__aenter__.return_value
        response.json = AsyncMock(return_value={'queue_running':[], 'queue_pending':[]})
        for blank_file in (False, True):
            form = FormData(default_to_multipart=True)
            form.add_field('prompt', 'An orange ball rolling on grass.')
            if blank_file:
                form.add_field('images', b'', filename='', content_type='application/octet-stream')
            r = await self.client.post('/api/tasks',data=form,headers=headers)
            self.assertEqual(r.status,202,await r.text())
            job = server.ENGINE.jobs[(await r.json())['id']]
            self.assertEqual(job['recipe']['images'],[])
            server.ENGINE.remove(job)

    async def test_model_selection_preserves_two_stage_graph(self):
        recipe = dict(prompt='Test', seconds=0.9166666666666666, orientation='landscape', images=['test/1.png'], seed=42)
        original = server.ENGINE.prompt({'id':'test', 'recipe':dict(recipe, model='original')})
        dasiwa = server.ENGINE.prompt({'id':'test', 'recipe':dict(recipe, model='dasiwa-v2')})
        self.assertEqual(dasiwa['1']['inputs']['unet_name'], engine.MODELS['dasiwa-v2'][1])
        dasiwa['1']['inputs']['unet_name'] = original['1']['inputs']['unet_name']
        self.assertEqual(original, dasiwa)
        with self.assertRaises(KeyError):
            server.ENGINE.prompt({'id':'test', 'recipe':dict(recipe, model='../invalid')})


if __name__=='__main__':
    unittest.main()
