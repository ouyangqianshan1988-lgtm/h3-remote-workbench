const fs = require('node:fs');
const vm = require('node:vm');
const assert = require('node:assert/strict');
const source = fs.readFileSync(process.env.APP_SCRIPT || __dirname + '/web/app.js', 'utf8');
const refresh = source.slice(source.indexOf('async function refresh()'), source.indexOf("$('login-form').addEventListener"));
const prepare = source.slice(source.indexOf('async function prepareDownload(id)'), source.indexOf("$('task-form').addEventListener"));
const pending = [], rendered = [], nodes = {};
const context = vm.createContext({
  token: 'alice-session', currentUsername: 'alice', downloading: false,
  api: () => new Promise((resolve, reject) => pending.push({resolve, reject})),
  $: id => nodes[id] ||= {value: '', textContent: '', options: [], replaceChildren() {}},
  updateInputCapabilities() {}, updateLoraOptions() {},
  renderTasks: tasks => rendered.push(tasks), Option: function() {},
  downloadLinks: new Map(),
});
vm.runInContext(refresh + prepare, context);
(async () => {
  const oldRefresh = context.refresh();
  context.token = 'bob-session'; context.currentUsername = 'bob';
  const freshRefresh = context.refresh();
  pending[1].resolve({username:'bob', tasks:[], models:[], message:'bob'});
  await freshRefresh;
  pending[0].resolve({username:'alice', tasks:[{id:'private-alice'}], models:[], message:'alice'});
  await oldRefresh;
  assert.equal(rendered.length, 1);
  assert.equal(rendered[0].length, 0);
  assert.equal(nodes['service-message'].textContent, 'bob');
  const oldLink = context.prepareDownload('bob-job');
  context.token = 'carol-session'; context.currentUsername = 'carol';
  pending[2].resolve({path:'/files/bob-job', expires:9999999999});
  await oldLink;
  assert.equal(context.downloadLinks.size, 0);
  console.log('PASS: late account-A task response and late account-B link cannot enter another session');
})().catch(error => { console.error(error); process.exitCode = 1; });
