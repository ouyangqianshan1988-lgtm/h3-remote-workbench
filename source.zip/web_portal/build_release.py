"""Build an explicit allowlisted release; never archive the private directory."""
import json
import zipfile
from pathlib import Path

root = Path(__file__).resolve().parent
release = root / 'private/release'
release.mkdir(parents=True, exist_ok=True)
html = (root / 'web/index.html').read_text(encoding='utf-8')
html = html.replace('<link rel="stylesheet" href="style.css">', '<style>' + (root / 'web/style.css').read_text(encoding='utf-8') + '</style>')
html = html.replace('<script defer src="config.js"></script>', '<script src="config.js"></script>')
html = html.replace('<script defer src="app.js"></script>', '')
html = html.replace('</body>', '<script>' + (root / 'web/app.js').read_text(encoding='utf-8') + '</script></body>')
(release / 'index.html').write_text(html, encoding='utf-8')
settings = json.loads((root / 'private/settings.json').read_text(encoding='utf-8'))
(release / 'config.js').write_text('window.PORTAL_API = ' + json.dumps(settings['public_api']) + ';\n', encoding='utf-8')
(release / 'README.md').write_text((root / 'README.md').read_text(encoding='utf-8'), encoding='utf-8')
files = ['.gitignore','server.py','engine.py','start.py','test_security.py','build_release.py','workflow.json','README.md',
         'web/index.html','web/style.css','web/app.js','web/config.js','monitor/index.html','monitor/status.html']
with zipfile.ZipFile(release / 'source.zip', 'w', zipfile.ZIP_DEFLATED) as archive:
    for name in files:
        archive.write(root / name, 'web_portal/' + name)
    archive.write(root.parent / 'Start_H3_Web.bat', 'Start_H3_Web.bat')
print('Release built from explicit allowlist.')
