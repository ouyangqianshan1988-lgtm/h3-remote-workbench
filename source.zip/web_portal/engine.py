import asyncio
import copy
import json
import os
import secrets
import shutil
import subprocess
import time
import uuid
from pathlib import Path

import aiohttp
import psutil

ROOT = Path(__file__).resolve().parent
BUNDLE = ROOT.parent
RUNTIME = ROOT / 'private/runtime'
WORKER = 'http://127.0.0.1:8191'
MODELS = {
    'original': ('原版 H3', 'minimax_h3_ref2va_pruned_int8_convrot.safetensors'),
    'dasiwa-v2': ('DaSiWa H3 Hybrid V2', 'DasiwaMinimaxH3_dasiwaHybridV2_3203130.safetensors'),
}


def model_options():
    return [{'id': key, 'name': label, 'available': (BUNDLE / 'ComfyUI/models/diffusion_models' / filename).is_file()}
            for key, (label, filename) in MODELS.items()]


def erase(path):
    path = path.resolve()
    if not path.is_relative_to(RUNTIME.resolve()) or path == RUNTIME.resolve():
        raise ValueError('Cleanup target outside task runtime')
    if path.is_dir():
        shutil.rmtree(path)
    elif path.exists():
        path.unlink()


class Engine:
    def __init__(self):
        self.jobs = {}
        self.queue = asyncio.Queue(maxsize=4)
        self.ready = False
        self.process = None
        self.client = None
        self.runner = None
        self.reaper = None
        self.template = json.loads((ROOT / 'workflow.json').read_text(encoding='utf-8'))

    async def request(self, method, route, **kwargs):
        async with self.client.request(method, WORKER + route, **kwargs) as response:
            if response.status >= 400:
                raise RuntimeError('工作流服务未能完成请求')
            if response.content_type == 'application/json':
                return await response.json()

    async def start(self):
        for part in ('input', 'output', 'temp', 'user'):
            (RUNTIME / part).mkdir(parents=True, exist_ok=True)
        # Recover only the dedicated worker created by this gateway.
        marker = ROOT / 'private/worker.json'
        if marker.exists():
            record = json.loads(marker.read_text())
            try:
                previous = psutil.Process(record['pid'])
                args = previous.cmdline()
                if str(RUNTIME / 'input') not in args or str(BUNDLE / 'ComfyUI/main.py') not in args:
                    raise RuntimeError('旧工作进程标识不匹配，请检查')
                previous.terminate()
                await asyncio.to_thread(previous.wait, 15)
            except psutil.NoSuchProcess:
                pass
        for part in ('input', 'output', 'temp'):
            for path in (RUNTIME / part).iterdir():
                erase(path)
        env = os.environ.copy()
        env.update(PYTHONUTF8='1', PYTHONIOENCODING='utf-8', PYTHONNOUSERSITE='1',
                   HF_HUB_OFFLINE='1', TRANSFORMERS_OFFLINE='1', HF_HUB_DISABLE_TELEMETRY='1')
        for key in ('PYTHONHOME', 'PYTHONPATH'):
            env.pop(key, None)
        command = [str(BUNDLE / 'python/python.exe'), '-s', str(BUNDLE / 'ComfyUI/main.py'),
                   '--listen', '127.0.0.1', '--port', '8191', '--disable-api-nodes',
                   '--preview-method', 'none', '--disable-metadata', '--cache-none',
                   '--reserve-vram', '1.5', '--async-offload', '2',
                   '--database-url', 'sqlite:///:memory:', '--front-end-root', str(ROOT / 'monitor')]
        for part in ('input', 'output', 'temp', 'user'):
            command += [f'--{part}-directory', str(RUNTIME / part)]
        self.process = subprocess.Popen(command, cwd=BUNDLE / 'ComfyUI', env=env,
                                        stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL,
                                        creationflags=subprocess.CREATE_NO_WINDOW)
        marker.write_text(json.dumps({'pid': self.process.pid}), encoding='utf-8')
        self.client = aiohttp.ClientSession(timeout=aiohttp.ClientTimeout(total=30))
        for _ in range(120):
            if self.process.poll() is not None:
                raise RuntimeError('专用工作进程启动失败')
            try:
                await self.request('GET', '/system_stats')
                self.ready = True
                break
            except (aiohttp.ClientError, asyncio.TimeoutError):
                await asyncio.sleep(1)
        if not self.ready:
            raise RuntimeError('工作流启动超时')
        self.runner = asyncio.create_task(self.run())
        self.reaper = asyncio.create_task(self.expire())

    def summary(self, job):
        return {k: job[k] for k in ('id', 'state', 'progress', 'created', 'message')}

    def new_job(self, username):
        active = {'uploading', 'queued', 'running', 'ready', 'downloading'}
        if any(j['owner'] == username and j['state'] in active for j in self.jobs.values()):
            raise ValueError('请先完成或清理已有任务')
        if self.queue.full():
            raise ValueError('任务队列已满，请稍后重试')
        key = str(uuid.uuid4())
        job = dict(id=key, owner=username, state='uploading', progress=0,
                   created=time.time(), updated=time.time(), message='正在接收任务',
                   receipt=secrets.token_urlsafe(32), delivered=False)
        self.jobs[key] = job
        (RUNTIME / 'input' / key).mkdir()
        (RUNTIME / 'output' / key).mkdir()
        return job

    def prompt(self, job):
        recipe = job.pop('recipe')
        graph = copy.deepcopy(self.template)
        graph['1']['inputs']['unet_name'] = MODELS[recipe.get('model', 'original')][1]
        portrait = recipe['orientation'] == 'portrait'
        width, height = (736, 1280) if portrait else (1280, 736)
        timeline = {'version': 9, 'fps': 24, 'selection': {'start': 0, 'duration': recipe['seconds']},
                    'globalPrompt': recipe['prompt'],
                    'images': [{'id': f'picture-{i+1}', 'file': path, 'name': f'Picture {i+1}'}
                               for i, path in enumerate(recipe['images'])],
                    'videoClips': [], 'audios': [], 'videoAudioEnabled': True,
                    'segmentConfig': {'count': 0, 'mode': 'timeline', 'activeIndex': 0, 'segments': []},
                    'secondPass': True, 'secondPassHighSteps': 2,
                    'secondPassModel': 'minimax_h3_latent_upscaler_3d_conv_v1_bf16.safetensors'}
        graph['7']['inputs'].update(width=width, height=height, generation_seconds=recipe['seconds'],
                                   timeline_data=json.dumps(timeline, ensure_ascii=False))
        graph['8']['inputs']['seed'] = recipe['seed']
        graph['13']['inputs'].update(width=720 if portrait else 1280, height=1280 if portrait else 720,
                                    x=8 if portrait else 0, y=0 if portrait else 8)
        graph['10']['inputs']['filename_prefix'] = job['id'] + '/result'
        return graph

    async def run(self):
        while True:
            job = await self.queue.get()
            try:
                if job['state'] != 'queued':
                    continue
                job.update(state='running', message='正在生成', updated=time.time())
                graph = self.prompt(job)
                result = await self.request('POST', '/prompt', json={'prompt': graph, 'prompt_id': job['id']})
                del graph
                if result.get('node_errors'):
                    raise RuntimeError('工作流参数校验失败')
                started = time.monotonic()
                while time.monotonic() - started < 1800:
                    if self.process.poll() is not None:
                        raise RuntimeError('工作进程已停止')
                    history = await self.request('GET', '/history/' + job['id'])
                    entry = history.get(job['id'])
                    if entry:
                        if entry['status']['status_str'] != 'success':
                            raise RuntimeError('生成失败，请减少时长后重试')
                        files = list((RUNTIME / 'output' / job['id']).glob('*.mp4'))
                        if len(files) != 1:
                            raise RuntimeError('未找到可下载的视频')
                        job.update(state='ready', progress=100, message='已完成，等待下载',
                                   output=files[0], updated=time.time())
                        break
                    await asyncio.sleep(2)
                else:
                    raise RuntimeError('生成超时')
            except asyncio.CancelledError:
                raise
            except Exception:
                # Never forward raw Comfy errors, prompt contents or file names.
                job.update(state='failed', message='生成失败，临时文件已清理', updated=time.time())
                # A failed/timeout worker may still hold open files. Stop it before deleting.
                self.ready = False
                if self.process.poll() is None:
                    self.process.terminate()
                    await asyncio.to_thread(self.process.wait, 15)
                self.clean_files(job)
                for pending in self.jobs.values():
                    if pending['state'] == 'queued':
                        self.clean_files(pending)
                        pending.update(state='failed', message='工作站已停止，临时文件已清理', updated=time.time())
            finally:
                if self.ready:
                    try:
                        await self.request('POST', '/history', json={'delete': [job['id']]})
                        await self.request('POST', '/free', json={'free_memory': True})
                    except (aiohttp.ClientError, asyncio.TimeoutError, RuntimeError):
                        self.ready = False
                self.queue.task_done()

    def clean_files(self, job):
        job.pop('recipe', None)
        job.pop('output', None)
        for part in ('input', 'output'):
            erase(RUNTIME / part / job['id'])

    def remove(self, job):
        if job['state'] in {'running', 'downloading', 'uploading'}:
            raise ValueError('任务仍在处理，请稍后再清理')
        self.clean_files(job)
        job.update(state='deleted', message='本机文件已清理', updated=time.time())

    async def expire(self):
        while True:
            await asyncio.sleep(30)
            for job in list(self.jobs.values()):
                age = time.time() - job['updated']
                if job['state'] == 'ready' and age > 3600:
                    self.remove(job)
                elif job['state'] in {'deleted', 'failed'} and age > 60:
                    self.jobs.pop(job['id'], None)

    async def close(self):
        self.ready = False
        for task in (self.runner, self.reaper):
            if task:
                task.cancel()
        await asyncio.gather(*(t for t in (self.runner, self.reaper) if t), return_exceptions=True)
        if self.process and self.process.poll() is None:
            self.process.terminate()
            await asyncio.to_thread(self.process.wait, 15)
        if self.client:
            await self.client.close()
        for job in list(self.jobs.values()):
            self.clean_files(job)
