import asyncio
import copy
import json
import math
import os
import secrets
import shutil
import subprocess
import time
import uuid
import re
from datetime import datetime, timezone, timedelta
from pathlib import Path

import aiohttp
import psutil

ROOT = Path(__file__).resolve().parent
BUNDLE = ROOT.parent
RUNTIME = ROOT / 'private/runtime'
FAILURE_LOG = ROOT / 'private/failure_logs/failures.jsonl'
FAILURE_LOG_MAX_RECORDS = 200
FAILURE_LOG_MAX_BYTES = 256 * 1024
WORKER = 'http://127.0.0.1:8291'
YZ_COMFY = Path(r'E:/BaiduNetdiskDownload/YZ金鱼-Minimax H3 纯净整合包/感谢秋叶-ComfyUI-aki-v3.2/ComfyUI-aki-v3.2/ComfyUI')
YZ_PYTHON = YZ_COMFY.parent / 'python/python.exe'
MODEL_PATHS_CONFIG = ROOT / 'private/yz_goldfish/model_paths.yaml'
YZ_API_WORKFLOW = ROOT / 'private/yz_goldfish/workflow_api.json'
ARCHIVE_ROOT = Path('E:/归档')
DASIWA_TURBO_LORA_CONFIG = ROOT / 'private/dasiwa_turbo/lora.json'
YZ_FIGHT_LORA = 'H3_Combat_V2.safetensors'


def yz_fight_lora_available():
    """Only expose the Combat V2 adapter used in today's controlled YZ tests."""
    return (YZ_COMFY / 'models/loras' / YZ_FIGHT_LORA).is_file()


def dasiwa_turbo_lora():
    """Return the explicitly installed DaSiWa Turbo LoRA config, if it is safe to use."""
    try:
        config = json.loads(DASIWA_TURBO_LORA_CONFIG.read_text(encoding='utf-8'))
        filename = config['filename']
        strength = float(config.get('strength', 1.0))
        if (not isinstance(filename, str) or Path(filename).name != filename
                or not filename.lower().endswith('.safetensors') or not 0 < strength <= 2):
            return None
        path = BUNDLE / 'ComfyUI/models/loras' / filename
        if not path.is_file():
            return None
        return {'filename': filename, 'strength': strength}
    except (OSError, ValueError, KeyError, TypeError):
        return None


def archive_directory(username):
    if not re.fullmatch(r'[A-Za-z0-9_-]{1,64}', username):
        raise ValueError('归档账号名称无效')
    if not ARCHIVE_ROOT.parent.exists():
        raise ValueError('归档磁盘未连接，暂不能提交附账号任务')
    folder = (ARCHIVE_ROOT / username).resolve()
    if not folder.is_relative_to(ARCHIVE_ROOT.resolve()):
        raise ValueError('归档路径无效')
    folder.mkdir(parents=True, exist_ok=True)
    return folder
MODELS = {
    'yz-goldfish': ('YZ金鱼', 'minimax_h3_hybrid_fl2va_ref2va_b25-49-int8.safetensors'),
    'dasiwa-turbo-v3': ('DaSiWa Turbo V3', 'DasiwaMinimaxH3_dasiwaHybridTurboV3_3263048.safetensors'),
}

ASPECT_RATIOS = {
    '16:9': (16, 9), '9:16': (9, 16), '1:1': (1, 1),
    '4:3': (4, 3), '3:4': (3, 4), '3:2': (3, 2),
    '2:3': (2, 3), '21:9': (21, 9),
}
RESOLUTION_BOUNDS = {'720p': (1280, 1280 * 736),
                     '768p': (1344, 1344 * 768),
                     '1080p': (1920, 1920 * 1088)}


def dimensions_for(resolution, aspect_ratio):
    """Return 32-aligned dimensions within the selected pixel budget and long-edge cap."""
    if resolution not in RESOLUTION_BOUNDS or aspect_ratio not in ASPECT_RATIOS:
        raise ValueError('分辨率或画幅比例无效')
    max_edge, area = RESOLUTION_BOUNDS[resolution]
    ratio = ASPECT_RATIOS[aspect_ratio][0] / ASPECT_RATIOS[aspect_ratio][1]
    width, height = math.sqrt(area * ratio), math.sqrt(area / ratio)
    scale = min(1.0, max_edge / max(width, height))
    width, height = width * scale, height * scale
    # Round half up to ComfyUI's 32-pixel alignment.
    width = max(32, math.floor(width / 32 + 0.5) * 32)
    height = max(32, math.floor(height / 32 + 0.5) * 32)
    return width, height


def model_path(model):
    if model == 'yz-goldfish':
        return YZ_COMFY / 'models/diffusion_models' / MODELS[model][1]
    return BUNDLE / 'ComfyUI/models/diffusion_models' / MODELS[model][1]


def model_options():
    return [{'id': key, 'name': label, 'available': model_path(key).is_file()}
            for key, (label, filename) in MODELS.items()]


def erase(path):
    path = path.resolve()
    if not path.is_relative_to(RUNTIME.resolve()) or path == RUNTIME.resolve():
        raise ValueError('Cleanup target outside task runtime')
    if path.is_dir():
        shutil.rmtree(path)
    elif path.exists():
        path.unlink()


def select_video_output(directory):
    """Prefer VHS's final audio-muxed MP4 over its intermediate silent MP4."""
    files = [path for path in Path(directory).glob('*.mp4') if path.is_file()]
    muxed = [path for path in files if path.stem.casefold().endswith('-audio')]
    if len(muxed) == 1:
        return muxed[0]
    if not muxed and len(files) == 1:
        return files[0]
    return None


class Engine:
    def __init__(self):
        self.jobs = {}
        self.queue = asyncio.Queue(maxsize=32)
        self.ready = False
        self.process = None
        self.client = None
        self.runner = None
        self.reaper = None
        self.template = json.loads((ROOT / 'workflow.json').read_text(encoding='utf-8'))
        self.yz_template = json.loads(YZ_API_WORKFLOW.read_text(encoding='utf-8'))

    async def request(self, method, route, **kwargs):
        async with self.client.request(method, WORKER + route, **kwargs) as response:
            if response.status >= 400:
                raise RuntimeError('工作流服务未能完成请求')
            if response.content_type == 'application/json':
                return await response.json()

    async def start(self):
        for part in ('input', 'output', 'temp', 'user'):
            (RUNTIME / part).mkdir(parents=True, exist_ok=True)
        preserved = set()
        resume_file = os.environ.get('PORTAL_RESUME_READY')
        if resume_file:
            preserved = self.restore_ready_jobs(Path(resume_file))
        # Recover only the dedicated worker created by this gateway.
        marker = ROOT / 'private/worker.json'
        if marker.exists():
            record = json.loads(marker.read_text())
            try:
                previous = psutil.Process(record['pid'])
                args = previous.cmdline()
                if str(RUNTIME / 'input') not in args or str(YZ_COMFY / 'main.py') not in args:
                    raise RuntimeError('旧工作进程标识不匹配，请检查')
                previous.terminate()
                await asyncio.to_thread(previous.wait, 15)
            except psutil.NoSuchProcess:
                pass
        # Recover outputs awaiting archive before allowing runtime cleanup.
        for manifest in (RUNTIME / 'output').glob('*/archive.json'):
            record = json.loads(manifest.read_text(encoding='utf-8'))
            key = manifest.parent.name
            if str(uuid.UUID(key)) != key:
                raise RuntimeError('归档恢复记录无效')
            files = list(manifest.parent.glob('*.mp4'))
            if len(files) != 1:
                raise RuntimeError('待归档结果不完整，停止清理')
            await asyncio.to_thread(self.archive_output, dict(id=key, owner=record['owner'], output=files[0], filename=record.get('filename')))
        for part in ('input', 'output', 'temp'):
            for path in (RUNTIME / part).iterdir():
                if part in {'input', 'output'} and path.name in preserved:
                    continue
                erase(path)
        env = os.environ.copy()
        env.update(PYTHONUTF8='1', PYTHONIOENCODING='utf-8', PYTHONNOUSERSITE='1',
                   HF_HUB_OFFLINE='1', TRANSFORMERS_OFFLINE='1', HF_HUB_DISABLE_TELEMETRY='1')
        for key in ('PYTHONHOME', 'PYTHONPATH'):
            env.pop(key, None)
        command = [str(YZ_PYTHON), '-s', str(YZ_COMFY / 'main.py'),
                   '--listen', '127.0.0.1', '--port', '8291', '--disable-api-nodes',
                   '--preview-method', 'none', '--disable-metadata', '--cache-none',
                   '--reserve-vram', '1.5', '--async-offload', '2',
                   '--database-url', 'sqlite:///:memory:',
                   '--extra-model-paths-config', str(MODEL_PATHS_CONFIG)]
        for part in ('input', 'output', 'temp', 'user'):
            command += [f'--{part}-directory', str(RUNTIME / part)]
        self.process = subprocess.Popen(command, cwd=BUNDLE / 'ComfyUI', env=env,
                                        stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL,
                                        creationflags=subprocess.CREATE_NO_WINDOW)
        marker.write_text(json.dumps({'pid': self.process.pid}), encoding='utf-8')
        self.client = aiohttp.ClientSession(timeout=aiohttp.ClientTimeout(total=30))
        for _ in range(120):
            if self.process.poll() is not None:
                raise RuntimeError('专用工作进程启动失败')
            try:
                await self.request('GET', '/system_stats')
                self.ready = True
                break
            except (aiohttp.ClientError, asyncio.TimeoutError):
                await asyncio.sleep(1)
        if not self.ready:
            raise RuntimeError('工作流启动超时')
        self.runner = asyncio.create_task(self.run())
        self.reaper = asyncio.create_task(self.expire())

    def restore_ready_jobs(self, snapshot):
        """Explicit maintenance handoff only; never accept client-controlled paths."""
        restored = {}
        for row in json.loads(snapshot.read_text(encoding='utf-8')):
            key, owner = row['id'], row['owner']
            if (str(uuid.UUID(key)) != key or row['state'] != 'ready'
                    or not re.fullmatch(r'[A-Za-z0-9_-]{1,64}', owner)
                    or not re.fullmatch(r'\d{12}(?:_\d+)?\.mp4', row['filename'])):
                raise ValueError('维护恢复记录无效，停止启动以保护结果')
            if row.get('archive'):
                output = archive_directory(owner) / Path(row['filename']).stem / row['filename']
            else:
                output = select_video_output(RUNTIME / 'output' / key)
            if output is None or not output.is_file():
                raise ValueError('待恢复结果缺失，停止启动')
            restored[key] = dict(id=key, owner=owner, state='ready', progress=100,
                                 created=row['created'], updated=time.time(),
                                 message=row.get('message', '已完成，等待下载'),
                                 filename=row['filename'], archive=bool(row.get('archive')),
                                 archived=bool(row.get('archive')), output=output,
                                 receipt=secrets.token_urlsafe(32), delivered=False,
                                 uploaded=asyncio.Event())
            restored[key]['uploaded'].set()
        self.jobs.update(restored)
        return set(restored)

    def summary(self, job):
        return {k: job[k] for k in ('id', 'state', 'progress', 'created', 'message', 'filename') if k in job}

    def record_failure(self, job, code, stage, exit_code=None, worker_alive=None):
        """Persist bounded, allowlisted diagnostics only; never serialize job/error payloads."""
        try:
            recipe = job.get('recipe') or job.get('_failure_meta') or {}
            model = recipe.get('model', 'original')
            if model not in MODELS:
                model = 'unknown'
            resolution = recipe.get('resolution', '720p')
            if resolution not in {'720p', '768p', '1080p'}:
                resolution = 'unknown'
            try:
                seconds = round(float(recipe.get('seconds')), 2)
                if not 0 < seconds <= 30:
                    seconds = None
            except (TypeError, ValueError):
                seconds = None
            orientation = recipe.get('orientation')
            if orientation not in {'landscape', 'portrait'}:
                orientation = 'unknown'
            aspect_ratio = recipe.get('aspect_ratio', '16:9')
            if aspect_ratio not in ASPECT_RATIOS:
                aspect_ratio = 'unknown'
            record = {
                'time_utc': datetime.now(timezone.utc).isoformat(timespec='seconds'),
                'task': str(job.get('id', ''))[:8],
                'code': code if code in {'workflow_validation', 'worker_exited', 'comfy_execution_failed',
                                         'output_missing', 'generation_timeout', 'backend_request_failed',
                                         'worker_stopped', 'internal_error'} else 'internal_error',
                'stage': stage if stage in {'submit', 'poll', 'output', 'generation', 'queue'} else 'generation',
                'model': model,
                'resolution': resolution,
                'seconds': seconds,
                'orientation': orientation,
                'aspect_ratio': aspect_ratio,
                'worker_alive': worker_alive if isinstance(worker_alive, bool) else None,
                'worker_exit_code': exit_code if isinstance(exit_code, int) else None,
            }
            FAILURE_LOG.parent.mkdir(parents=True, exist_ok=True)
            lines = FAILURE_LOG.read_text(encoding='utf-8').splitlines() if FAILURE_LOG.exists() else []
            lines.append(json.dumps(record, ensure_ascii=True, separators=(',', ':')))
            lines = lines[-FAILURE_LOG_MAX_RECORDS:]
            data = ('\n'.join(lines) + '\n').encode('utf-8')
            while len(data) > FAILURE_LOG_MAX_BYTES and len(lines) > 1:
                lines.pop(0)
                data = ('\n'.join(lines) + '\n').encode('utf-8')
            temporary = FAILURE_LOG.with_suffix('.jsonl.tmp')
            temporary.write_bytes(data)
            os.replace(temporary, FAILURE_LOG)
        except Exception:
            # Diagnostics must never interfere with task cleanup or recovery.
            try:
                FAILURE_LOG.with_suffix('.jsonl.tmp').unlink(missing_ok=True)
            except OSError:
                pass

    def result_filename(self, job):
        if job.get('filename'):
            if not re.fullmatch(r'\d{12}(?:_\d+)?\.mp4', job['filename']):
                raise ValueError('结果文件名无效')
            return job['filename']
        stamp = datetime.fromtimestamp(job.get('completed', job['output'].stat().st_mtime), timezone(timedelta(hours=8))).strftime('%Y%m%d%H%M')
        folder = ARCHIVE_ROOT / job['owner']
        used = {j.get('filename') for j in self.jobs.values() if j['owner'] == job['owner']}
        name, sequence = stamp + '.mp4', 1
        while name in used or (folder / name).exists() or (folder / Path(name).stem).exists():
            sequence += 1
            name = f'{stamp}_{sequence}.mp4'
        job['filename'] = name
        return name

    def new_job(self, username, archive=False):
        active = {'uploading', 'queued', 'running', 'ready', 'downloading', 'archive_pending'}
        if any(j['owner'] == username and j['state'] in active for j in self.jobs.values()):
            raise ValueError('请先完成或清理已有任务')
        if sum(j['state'] in {'uploading','queued'} for j in self.jobs.values()) >= 32:
            raise ValueError('任务队列已满，请稍后重试')
        key = str(uuid.uuid4())
        job = dict(id=key, owner=username, state='uploading', progress=0,
                   created=time.time(), updated=time.time(), message='正在接收任务',
                   receipt=secrets.token_urlsafe(32), delivered=False, archive=archive,
                   uploaded=asyncio.Event())
        self.jobs[key] = job
        (RUNTIME / 'input' / key).mkdir()
        (RUNTIME / 'output' / key).mkdir()
        self.queue.put_nowait(job)
        return job

    def archive_output(self, job):
        if job.get('archived'):
            return
        folder = archive_directory(job['owner'])
        filename = self.result_filename(job)
        stem = Path(filename).stem
        target = folder / stem
        manifest = job['output'].parent / 'archive.json'
        manifest.write_text(json.dumps({'owner': job['owner'], 'filename': filename}), encoding='utf-8')
        source_dir = RUNTIME / 'input' / job['id']
        prompt = source_dir / 'prompt.txt'
        sources = {filename: job['output']}
        if prompt.exists():
            sources[stem + '.txt'] = prompt
        for index, picture in enumerate(sorted(source_dir.glob('*.png')), 1):
            sources[f'picture{index}.png'] = picture
        for pattern, prefix in (('ref_video_*', 'video'), ('ref_audio_*', 'audio')):
            for index, media in enumerate(sorted(source_dir.glob(pattern)), 1):
                sources[f'{prefix}{index}{media.suffix.lower()}'] = media
        if target.exists():
            import hashlib
            for name, source in sources.items():
                with (target / name).open('rb') as saved, source.open('rb') as original:
                    if hashlib.file_digest(saved, 'sha256').digest() != hashlib.file_digest(original, 'sha256').digest():
                        raise OSError('归档文件冲突')
        else:
            temporary = folder / (job['id'] + '.pending')
            temporary.mkdir(exist_ok=True)
            for name, source in sources.items():
                shutil.copyfile(source, temporary / name)
            if not prompt.exists():
                (temporary / (stem + '.txt')).write_text('', encoding='utf-8')
            temporary.rename(target)
        manifest.unlink(missing_ok=True)
        job['archived'] = True
        self.clean_files(job)
        job['output'] = target / filename

    def prompt(self, job):
        recipe = job.pop('recipe')
        model = recipe.get('model', 'yz-goldfish')
        if model not in MODELS:
            raise ValueError('所选工作流未开放')
        if job.get('archive'):
            (RUNTIME / 'input' / job['id'] / 'prompt.txt').write_text(recipe['prompt'], encoding='utf-8')
        if model in {'dasiwa-turbo-v3', 'yz-goldfish'}:
            graph = copy.deepcopy(self.yz_template)
            graph['192']['inputs']['unet_name'] = MODELS[model][1]
            if model == 'yz-goldfish':
                # Today's validated YZ quality setup: beta sigmas, Euler, 10
                # steps with a 6+4 SelfLift transition. Keep the fighting
                # adapter optional because the A/B did not show a clear win.
                graph['261']['inputs'].update(scheduler='beta', steps=10)
                graph['397']['inputs']['transition_step'] = 6
                graph['397']['inputs']['highres_tiling'] = True
                graph['265']['inputs']['ref_image_size'] = 'max'
                model_input = ['400', 0]
                if recipe.get('use_yz_fight_lora'):
                    if not yz_fight_lora_available():
                        raise ValueError('YZ 金鱼武打 LoRA 尚未安装完成')
                    graph['8900'] = {'class_type': 'LoraLoaderModelOnly', 'inputs': {
                        'model': model_input,
                        'lora_name': YZ_FIGHT_LORA,
                        'strength_model': recipe.get('yz_fight_lora_strength', 0.65)}}
                    model_input = ['8900', 0]
                if recipe.get('use_yz_dasiwa_lora'):
                    lora = dasiwa_turbo_lora()
                    if not lora:
                        raise ValueError('DaSiWa Turbo LoRA 尚未安装完成')
                    graph['8901'] = {'class_type': 'LoraLoaderModelOnly', 'inputs': {
                        'model': model_input,
                        'lora_name': lora['filename'],
                        'strength_model': recipe.get('yz_dasiwa_lora_strength', lora['strength'])}}
                    model_input = ['8901', 0]
                graph['331']['inputs']['model'] = model_input
            else:
                # The old workflow depended on timeline-planner/finite-segment
                # nodes absent from the new bundle. Reuse its native H3 graph,
                # retaining the Turbo V3 6+2 SelfLift pass on the new ComfyUI.
                graph.pop('53', None)
                graph.pop('400', None)
                model_input = ['192', 0]
                if recipe.get('use_lora'):
                    lora = dasiwa_turbo_lora()
                    if not lora:
                        raise ValueError('DaSiWa Turbo LoRA 尚未安装完成')
                    graph['14'] = {'class_type': 'LoraLoaderModelOnly', 'inputs': {
                        'model': model_input,
                        'lora_name': lora['filename'],
                        'strength_model': recipe.get('lora_strength', lora['strength'])}}
                    model_input = ['14', 0]
                graph['331']['inputs']['model'] = model_input
                graph['261']['inputs']['steps'] = 8
                graph['397']['inputs']['transition_step'] = 6
                graph['364']['inputs']['crf'] = 18
            graph['265']['inputs'].update(prompt=recipe['prompt'])
            aspect_ratio = recipe.get('aspect_ratio')
            if not aspect_ratio:
                aspect_ratio = '9:16' if recipe.get('orientation') == 'portrait' else '16:9'
            width, height = dimensions_for(recipe.get('resolution', '720p'), aspect_ratio)
            graph['265']['inputs'].update(width=width, height=height)
            frames = max(5, round(recipe['seconds'] * 24))
            graph['265']['inputs']['length'] = frames + (5 - frames % 17) % 17
            graph['397']['inputs']['seed'] = recipe['seed']
            graph['329']['inputs']['preview_frames'] = 1
            graph['364']['inputs']['filename_prefix'] = job['id'] + '/result'
            for index, image in enumerate(recipe['images']):
                node_id = str(9001 + index)
                graph[node_id] = {'class_type': 'LoadImage',
                                  'inputs': {'image': f"{job['id']}/{index + 1}.png"}}
                graph['265']['inputs'][f'ref_images.ref_image_{index}'] = [node_id, 0]
            for index, video in enumerate(recipe.get('videos', [])):
                node_id = str(9101 + index)
                # VHS_LoadVideoPath validates a filesystem path from ComfyUI's
                # process cwd; unlike LoadImage, it does not resolve input-relative
                # subfolders. The browser upload is stored under our private input
                # directory, so pass its resolved path to VHS.
                video_path = str((RUNTIME / 'input' / video).resolve())
                graph[node_id] = {'class_type': 'VHS_LoadVideoPath', 'inputs': {
                    'video': video_path, 'force_rate': 24, 'custom_width': 0, 'custom_height': 0,
                    'frame_load_cap': 360, 'skip_first_frames': 0, 'select_every_nth': 1,
                    'format': 'H3'}}
                graph['265']['inputs'][f'ref_videos.ref_video_{index}'] = [node_id, 0]
                graph['265']['inputs'][f'ref_video_audios.ref_video_audio_{index}'] = [node_id, 2]
            for index, audio in enumerate(recipe.get('audios', [])):
                node_id = str(9201 + index)
                # VHS_LoadAudio also checks os.path.isfile() against the process
                # cwd, so a UUID-relative filename fails prompt validation.
                audio_path = str((RUNTIME / 'input' / audio).resolve())
                graph[node_id] = {'class_type': 'VHS_LoadAudio', 'inputs': {'audio_file': audio_path,
                                                                            'seek_seconds': 0, 'duration': 30}}
                graph['265']['inputs'][f'ref_audios.ref_audio_{index}'] = [node_id, 0]
            return graph
        raise ValueError('所选工作流未开放')

    async def run(self):
        while True:
            job = await self.queue.get()
            failure_code, failure_stage = 'internal_error', 'generation'
            try:
                await job['uploaded'].wait()
                if job['state'] != 'queued':
                    continue
                job.update(state='running', message='正在生成', updated=time.time())
                recipe = job.get('recipe') or {}
                # Keep only non-content fields needed for diagnostics before prompt() consumes the recipe.
                job['_failure_meta'] = {key: recipe.get(key) for key in
                                        ('model', 'resolution', 'seconds', 'orientation', 'aspect_ratio')}
                failure_stage = 'submit'
                graph = self.prompt(job)
                result = await self.request('POST', '/prompt', json={'prompt': graph, 'prompt_id': job['id']})
                del graph
                if result.get('node_errors'):
                    failure_code = 'workflow_validation'
                    raise RuntimeError('工作流参数校验失败')
                started = time.monotonic()
                failure_stage = 'poll'
                while time.monotonic() - started < 7200:
                    if self.process.poll() is not None:
                        failure_code = 'worker_exited'
                        raise RuntimeError('工作进程已停止')
                    history = await self.request('GET', '/history/' + job['id'])
                    entry = history.get(job['id'])
                    if entry:
                        if entry['status']['status_str'] != 'success':
                            failure_code = 'comfy_execution_failed'
                            raise RuntimeError('生成失败，请减少时长后重试')
                        failure_stage = 'output'
                        output = select_video_output(RUNTIME / 'output' / job['id'])
                        if output is None:
                            failure_code = 'output_missing'
                            raise RuntimeError('未找到可下载的视频')
                        job['output'] = output
                        job['completed'] = time.time()
                        self.result_filename(job)
                        if job.get('archive'):
                            try:
                                await asyncio.to_thread(self.archive_output, job)
                            except (OSError, ValueError):
                                job.update(state='archive_pending', message='生成完成，等待归档磁盘恢复', updated=time.time())
                                break
                        job.update(state='ready', progress=100, message='已归档，等待下载' if job.get('archived') else '已完成，等待下载',
                                   updated=time.time())
                        break
                    await asyncio.sleep(2)
                else:
                    failure_code = 'generation_timeout'
                    raise RuntimeError('生成超时')
            except asyncio.CancelledError:
                raise
            except Exception as exc:
                # Never forward raw Comfy errors, prompt contents or file names.
                if failure_code == 'internal_error':
                    failure_code = 'backend_request_failed' if isinstance(exc, (aiohttp.ClientError, asyncio.TimeoutError)) or str(exc) == '工作流服务未能完成请求' else 'internal_error'
                try:
                    worker_alive = self.process is not None and self.process.poll() is None
                    exit_code = self.process.poll() if self.process is not None else None
                except Exception:
                    worker_alive, exit_code = None, None
                self.record_failure(job, failure_code, failure_stage, exit_code, worker_alive)
                job.update(state='failed', message='生成失败，临时文件已清理', updated=time.time())
                # A failed/timeout worker may still hold open files. Stop it before deleting.
                self.ready = False
                if self.process.poll() is None:
                    self.process.terminate()
                    await asyncio.to_thread(self.process.wait, 15)
                self.clean_files(job)
                for pending in self.jobs.values():
                    if pending['state'] == 'queued':
                        self.record_failure(pending, 'worker_stopped', 'queue',
                                            self.process.poll() if self.process is not None else None, False)
                        self.clean_files(pending)
                        pending.update(state='failed', message='工作站已停止，临时文件已清理', updated=time.time())
            finally:
                if self.ready:
                    try:
                        await self.request('POST', '/history', json={'delete': [job['id']]})
                        await self.request('POST', '/free', json={'free_memory': True})
                    except (aiohttp.ClientError, asyncio.TimeoutError, RuntimeError):
                        self.ready = False
                self.queue.task_done()

    def clean_files(self, job):
        job.pop('recipe', None)
        job.pop('_failure_meta', None)
        job.pop('output', None)
        for part in ('input', 'output'):
            erase(RUNTIME / part / job['id'])

    def remove(self, job):
        if job['state'] in {'running', 'downloading', 'uploading', 'archive_pending'}:
            raise ValueError('任务仍在处理，请稍后再清理')
        self.clean_files(job)
        job.update(state='deleted', message='本机文件已清理', updated=time.time())

    async def expire(self):
        while True:
            await asyncio.sleep(30)
            for job in list(self.jobs.values()):
                age = time.time() - job['updated']
                if job['state'] == 'archive_pending':
                    try:
                        await asyncio.to_thread(self.archive_output, job)
                        job.update(state='ready', progress=100, message='已归档，等待下载', updated=time.time())
                    except (OSError, ValueError):
                        pass
                elif job['state'] in {'deleted', 'failed'} and age > 60:
                    self.jobs.pop(job['id'], None)

    async def close(self):
        self.ready = False
        for task in (self.runner, self.reaper):
            if task:
                task.cancel()
        await asyncio.gather(*(t for t in (self.runner, self.reaper) if t), return_exceptions=True)
        if self.process and self.process.poll() is None:
            self.process.terminate()
            await asyncio.to_thread(self.process.wait, 15)
        if self.client:
            await self.client.close()
        for job in list(self.jobs.values()):
            if (RUNTIME / 'output' / job['id'] / 'archive.json').exists():
                continue
            self.clean_files(job)
