"""Account gateway. Run using the portable bundle's Python."""
import asyncio
import hashlib
import hmac
import json
import os
import secrets
import time
import io
import sys
import msvcrt
from pathlib import Path

from aiohttp import web
from PIL import Image, UnidentifiedImageError
sys.path.insert(0, str(Path(__file__).resolve().parent))
from engine import Engine, RUNTIME

ROOT = Path(__file__).resolve().parent
USER_FILE = ROOT / 'private/users.json'
ORIGINS = {s.strip().rstrip('/') for s in os.environ.get('PORTAL_ORIGINS', '').split(',') if s.strip()}
SESSIONS = {}
ATTEMPTS = {}
ENGINE = Engine()


@web.middleware
async def boundary(request, handler):
    origin = request.headers.get('Origin')
    same_origin = origin == f'{request.scheme}://{request.host}'
    allowed = origin in ORIGINS or same_origin
    if origin and not allowed:
        return web.json_response({'error': '不允许的网页来源'}, status=403)
    try:
        response = web.Response(status=204) if request.method == 'OPTIONS' else await handler(request)
    except web.HTTPException as exc:
        response = web.json_response({'error': exc.reason}, status=exc.status)
    response.headers.update({'Cache-Control': 'no-store', 'X-Content-Type-Options': 'nosniff',
                             'Referrer-Policy': 'no-referrer', 'X-Frame-Options': 'DENY'})
    if origin and allowed:
        response.headers.update({'Access-Control-Allow-Origin': origin, 'Vary': 'Origin',
                                 'Access-Control-Allow-Headers': 'Authorization, Content-Type',
                                 'Access-Control-Allow-Methods': 'GET, POST, DELETE, OPTIONS'})
    return response


def account(request):
    token = request.headers.get('Authorization', '').removeprefix('Bearer ')
    session = SESSIONS.get(token)
    if not session or session['expires'] <= time.monotonic():
        SESSIONS.pop(token, None)
        raise web.HTTPUnauthorized(reason='请重新登录')
    return session['username']


async def login(request):
    if request.content_type != 'application/json':
        raise web.HTTPUnsupportedMediaType()
    if request.content_length is None or request.content_length > 4096:
        raise web.HTTPRequestEntityTooLarge(max_size=4096, actual_size=request.content_length or 0)
    key = request.remote or 'unknown'
    now = time.monotonic()
    ATTEMPTS[key] = [t for t in ATTEMPTS.get(key, []) if now - t < 300]
    if len(ATTEMPTS[key]) >= 8:
        raise web.HTTPTooManyRequests(reason='尝试次数过多，请五分钟后重试')
    ATTEMPTS[key].append(now)
    try:
        data = await request.json()
    except (ValueError, UnicodeDecodeError):
        raise web.HTTPBadRequest(reason='请求格式错误')
    if not isinstance(data, dict):
        raise web.HTTPBadRequest(reason='请求格式错误')
    username = data.get('username', '')
    password = data.get('password', '')
    if not isinstance(username, str) or not isinstance(password, str) or len(password) > 256:
        raise web.HTTPBadRequest(reason='账号格式错误')
    users = json.loads(USER_FILE.read_text(encoding='utf-8'))
    user = users.get(username)
    salt = bytes.fromhex(user['salt']) if user else bytes(32)
    digest = await asyncio.to_thread(hashlib.scrypt, password.encode(), salt=salt, n=16384, r=8, p=1)
    expected = user['password_hash'] if user else '0' * 128
    if not hmac.compare_digest(digest.hex(), expected) or not user or not user['enabled']:
        raise web.HTTPUnauthorized(reason='账号或密码错误')
    for token, session in list(SESSIONS.items()):
        if session['expires'] <= now:
            del SESSIONS[token]
    token = secrets.token_urlsafe(32)
    SESSIONS[token] = {'username': username, 'expires': now + 3600}
    return web.json_response({'token': token, 'username': username, 'expires_in': 3600})


async def logout(request):
    SESSIONS.pop(request.headers.get('Authorization', '').removeprefix('Bearer '), None)
    return web.json_response({'ok': True})


async def tasks(request):
    username = account(request)
    return web.json_response({'tasks': [ENGINE.summary(t) for t in ENGINE.jobs.values() if t['owner'] == username],
                             'accepting_tasks': ENGINE.ready,
                             'message': '工作站已连接。结果仅供下载，下载确认后清理；未下载结果一小时后清理。' if ENGINE.ready else '工作站尚未就绪，请稍后重试。'})


def owned_job(request):
    username = account(request)
    job = ENGINE.jobs.get(request.match_info['id'])
    if not job or job['owner'] != username:
        raise web.HTTPNotFound(reason='任务不存在')
    return job


def save_image(data, path):
    with Image.open(io.BytesIO(data)) as image:
        if image.width * image.height > 16_000_000:
            raise ValueError('参考图片不得超过1600万像素')
        image.convert('RGB').save(path, format='PNG')


async def submit(request):
    username = account(request)
    if not ENGINE.ready:
        raise web.HTTPServiceUnavailable(reason='工作站尚未就绪')
    try:
        async with ENGINE.client.get('http://127.0.0.1:8188/queue') as response:
            original = await response.json()
            if original.get('queue_running') or original.get('queue_pending'):
                raise web.HTTPConflict(reason='本机ComfyUI正在使用显卡，请稍后提交')
    except (OSError, asyncio.TimeoutError):
        pass
    if request.content_type != 'multipart/form-data':
        raise web.HTTPUnsupportedMediaType()
    try:
        job = ENGINE.new_job(username)
    except ValueError as exc:
        raise web.HTTPConflict(reason=str(exc))
    try:
        reader = await request.multipart()
        fields, images, total = {}, [], 0
        while part := await reader.next():
            data = bytearray()
            while chunk := await part.read_chunk(65536):
                data.extend(chunk)
                total += len(chunk)
                if total > 32 * 1024 * 1024 or len(data) > 8 * 1024 * 1024:
                    raise ValueError('每张图片最多8MB，任务总上传最多32MB')
            if part.name == 'images':
                if len(images) >= 4:
                    raise ValueError('测试版最多接收4张参考图')
                relative = f'{job["id"]}/{len(images)+1}.png'
                await asyncio.to_thread(save_image, data, RUNTIME / 'input' / relative)
                images.append(relative)
            elif part.name in {'prompt', 'seconds', 'orientation'}:
                if len(data) > 16000:
                    raise ValueError('文字内容过长')
                fields[part.name] = data.decode('utf-8')
            else:
                raise ValueError('未知任务参数')
        prompt = fields.get('prompt', '').strip()
        seconds = float(fields.get('seconds', '5.166666666666667'))
        orientation = fields.get('orientation', 'landscape')
        if not prompt or len(prompt) > 4000 or not images:
            raise ValueError('请填写提示词并上传至少一张参考图')
        if not 0.9 <= seconds <= 5.17 or orientation not in {'landscape', 'portrait'}:
            raise ValueError('画幅或时长参数不正确')
        job.update(recipe={'prompt': prompt, 'seconds': seconds, 'orientation': orientation,
                           'images': images, 'seed': secrets.randbelow(2**53)},
                   state='queued', message='等待工作站处理', updated=time.time())
        ENGINE.queue.put_nowait(job)
        return web.json_response(ENGINE.summary(job), status=202)
    except (ValueError, UnicodeDecodeError, UnidentifiedImageError, Image.DecompressionBombError) as exc:
        ENGINE.clean_files(job)
        ENGINE.jobs.pop(job['id'], None)
        raise web.HTTPBadRequest(reason=str(exc) if isinstance(exc, ValueError) else '图片格式不正确')
    except BaseException:
        ENGINE.clean_files(job)
        ENGINE.jobs.pop(job['id'], None)
        raise


async def download(request):
    job = owned_job(request)
    if job['state'] != 'ready':
        raise web.HTTPConflict(reason='结果尚不可下载')
    path = job['output']
    job['state'] = 'downloading'
    response = web.StreamResponse(headers={'Content-Type': 'application/octet-stream',
        'Content-Disposition': 'attachment; filename="H3-result.mp4"',
        'Content-Length': str(path.stat().st_size), 'X-Download-Receipt': job['receipt'],
        'Access-Control-Expose-Headers': 'X-Download-Receipt, Content-Length', 'Cache-Control': 'no-store'})
    try:
        await response.prepare(request)
        with path.open('rb') as handle:
            while chunk := handle.read(256 * 1024):
                await response.write(chunk)
        await response.write_eof()
        job['delivered'] = True
        return response
    finally:
        job.update(state='ready', updated=time.time())


async def downloaded(request):
    job = owned_job(request)
    data = await request.json()
    if not isinstance(data, dict):
        raise web.HTTPBadRequest()
    if not job['delivered'] or not hmac.compare_digest(str(data.get('receipt', '')), job['receipt']):
        raise web.HTTPConflict(reason='尚未完成下载传输')
    try:
        ENGINE.remove(job)
    except ValueError as exc:
        raise web.HTTPConflict(reason=str(exc))
    return web.json_response({'ok': True})


async def remove(request):
    job = owned_job(request)
    try:
        ENGINE.remove(job)
    except ValueError as exc:
        raise web.HTTPConflict(reason=str(exc))
    return web.json_response({'ok': True})


async def static(request):
    name = request.match_info.get('name') or 'index.html'
    if name not in {'index.html', 'app.js', 'style.css', 'config.js'}:
        raise web.HTTPNotFound()
    return web.FileResponse(ROOT / 'web' / name)


def make_app():
    app = web.Application(middlewares=[boundary], client_max_size=34 * 1024 * 1024)
    app.router.add_post('/api/login', login)
    app.router.add_post('/api/logout', logout)
    app.router.add_get('/api/tasks', tasks)
    app.router.add_post('/api/tasks', submit)
    app.router.add_get('/api/tasks/{id}/download', download)
    app.router.add_post('/api/tasks/{id}/downloaded', downloaded)
    app.router.add_delete('/api/tasks/{id}', remove)
    app.router.add_route('OPTIONS', '/api/{path:.*}', lambda request: web.Response(status=204))
    app.router.add_get('/', static)
    app.router.add_get('/{name}', static)
    app.on_response_prepare.append(response_headers)
    return app


async def response_headers(request, response):
    response.headers['Cache-Control'] = 'no-store'
    response.headers['X-Content-Type-Options'] = 'nosniff'
    response.headers['Referrer-Policy'] = 'no-referrer'
    origin = request.headers.get('Origin')
    if origin in ORIGINS or origin == f'{request.scheme}://{request.host}':
        response.headers['Access-Control-Allow-Origin'] = origin
        response.headers['Vary'] = 'Origin'


async def monitor_status(request):
    return web.json_response({'ready': ENGINE.ready, 'tasks': [ENGINE.summary(j) for j in ENGINE.jobs.values()
                             if j['state'] in {'queued', 'running', 'downloading'}]}, headers={'Cache-Control':'no-store'})


async def monitor_page(request):
    return web.FileResponse(ROOT / 'monitor/status.html')


async def lifecycle(app):
    runner = None
    try:
        await ENGINE.start()
        monitor = web.Application()
        monitor.router.add_get('/', monitor_page)
        monitor.router.add_get('/status', monitor_status)
        runner = web.AppRunner(monitor, access_log=None)
        await runner.setup()
        await web.TCPSite(runner, '127.0.0.1', 8192).start()
        yield
    finally:
        if runner:
            await runner.cleanup()
        await ENGINE.close()


if __name__ == '__main__':
    lock = (ROOT / 'private/server.lock').open('a+b')
    lock.seek(0)
    if not lock.read(1):
        lock.write(b'0')
        lock.flush()
    lock.seek(0)
    try:
        msvcrt.locking(lock.fileno(), msvcrt.LK_NBLCK, 1)
    except OSError:
        raise SystemExit('H3 gateway is already running.')
    app = make_app()
    app.cleanup_ctx.append(lifecycle)
    web.run_app(app, host='127.0.0.1', port=8190, access_log=None, print=None)
