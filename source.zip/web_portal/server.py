"""Account gateway. Run using the portable bundle's Python."""
import asyncio
import hashlib
import hmac
import json
import math
import os
import secrets
import time
import io
import sys
import msvcrt
from pathlib import Path

from aiohttp import web
from PIL import Image, UnidentifiedImageError
sys.path.insert(0, str(Path(__file__).resolve().parent))
from engine import (Engine, RUNTIME, MODELS, model_options, archive_directory,
                    dasiwa_turbo_lora, yz_fight_lora_available, ASPECT_RATIOS)

MAX_UPLOAD_BYTES = 90 * 1024 * 1024
UPLOAD_LIMITS = {'images': 8 * 1024 * 1024, 'videos': 40 * 1024 * 1024,
                 'audios': 16 * 1024 * 1024}
UPLOAD_EXTENSIONS = {
    'videos': {'.mp4', '.mov', '.mkv', '.webm', '.gif'},
    'audios': {'.wav', '.mp3', '.ogg', '.m4a', '.flac'},
}

ROOT = Path(__file__).resolve().parent
USER_FILE = ROOT / 'private/users.json'
SETTINGS_FILE = ROOT / 'private/settings.json'
_ENV_ORIGINS = {s.strip().rstrip('/') for s in os.environ.get('PORTAL_ORIGINS', '').split(',') if s.strip()}
_ORIGIN_CACHE = {'stamp': None, 'value': set()}


def allowed_origins():
    """允许的网页来源 = 环境变量 PORTAL_ORIGINS ∪ settings.json 的 origins。

    settings.json 按修改时间缓存，改完立刻生效、不用重启。这一点很重要：
    start.py 是先起服务、再调 tunnel.py 的，公网域名是在服务起来之后才写进
    settings.json 的 —— 如果只在启动时读一次，那个域名永远进不了白名单，
    浏览器发 POST 就会被判成跨域，报「不允许的网页来源」。
    """
    try:
        stamp = SETTINGS_FILE.stat().st_mtime_ns
    except OSError:
        return set(_ENV_ORIGINS)
    if _ORIGIN_CACHE['stamp'] != stamp:
        try:
            data = json.loads(SETTINGS_FILE.read_text(encoding='utf-8'))
            _ORIGIN_CACHE['value'] = {str(item).strip().rstrip('/')
                                      for item in data.get('origins', []) if str(item).strip()}
        except (OSError, ValueError):
            _ORIGIN_CACHE['value'] = set()
        _ORIGIN_CACHE['stamp'] = stamp
    return set(_ENV_ORIGINS) | _ORIGIN_CACHE['value']


# [lan] 监听地址。原来硬编码 127.0.0.1，只能本机访问，局域网和手机都打不开。
# 默认改成 0.0.0.0 = 局域网可访问（公网那边一直有 Tailscale Funnel 代理 127.0.0.1:8290，
# 通配监听同样覆盖回环地址，Funnel 不受影响）。
# 想恢复成只允许本机：启动前设 PORTAL_HOST=127.0.0.1。
PORTAL_HOST = os.environ.get('PORTAL_HOST', '0.0.0.0').strip() or '0.0.0.0'
SESSIONS = {}
ATTEMPTS = {}
ENGINE = Engine()
DOWNLOAD_COOKIE = 'h3_download_session'


def request_token(request):
    # An explicitly supplied account must take precedence over a browser cookie.
    return (request.headers['Authorization'].removeprefix('Bearer ')
            if 'Authorization' in request.headers else request.cookies.get(DOWNLOAD_COOKIE, ''))


def session_digest(token):
    return hashlib.sha256(token.encode()).hexdigest()


def set_download_cookie(response, request, token):
    secure = (request.scheme == 'https' or request.headers.get('X-Forwarded-Proto') == 'https'
              or request.headers.get('Origin', '').startswith('https://'))
    response.set_cookie(DOWNLOAD_COOKIE, token, httponly=True, secure=secure,
                        samesite='Lax', path='/files', max_age=3600)


def archives_enabled(username):
    users = json.loads(USER_FILE.read_text(encoding='utf-8'))
    return users.get(username, {}).get('archive', username != 'test')


def allowed_models(username):
    # Every signed-in account may select exactly the workflows published by the owner.
    return model_options()


@web.middleware
async def boundary(request, handler):
    origin = request.headers.get('Origin')
    same_origin = origin == f'{request.scheme}://{request.host}'
    allowed = same_origin or origin in allowed_origins()
    if origin and not allowed:
        return web.json_response({'error': '不允许的网页来源'}, status=403)
    try:
        response = web.Response(status=204) if request.method == 'OPTIONS' else await handler(request)
    except web.HTTPException as exc:
        response = web.json_response({'error': exc.reason}, status=exc.status)
    response.headers.update({'Cache-Control': 'no-store', 'X-Content-Type-Options': 'nosniff',
                             'Referrer-Policy': 'no-referrer', 'X-Frame-Options': 'DENY'})
    if origin and allowed:
        response.headers.update({'Access-Control-Allow-Origin': origin, 'Vary': 'Origin',
                                 'Access-Control-Allow-Credentials': 'true',
                                 'Access-Control-Allow-Headers': 'Authorization, Content-Type',
                                 'Access-Control-Allow-Methods': 'GET, POST, DELETE, OPTIONS'})
    return response


def account(request):
    token = request.headers.get('Authorization', '').removeprefix('Bearer ')
    session = SESSIONS.get(token)
    if not session or session['expires'] <= time.monotonic():
        SESSIONS.pop(token, None)
        raise web.HTTPUnauthorized(reason='请重新登录')
    return session['username']


async def login(request):
    if request.content_type != 'application/json':
        raise web.HTTPUnsupportedMediaType()
    if request.content_length is None or request.content_length > 4096:
        raise web.HTTPRequestEntityTooLarge(max_size=4096, actual_size=request.content_length or 0)
    key = request.remote or 'unknown'
    now = time.monotonic()
    ATTEMPTS[key] = [t for t in ATTEMPTS.get(key, []) if now - t < 300]
    if len(ATTEMPTS[key]) >= 8:
        raise web.HTTPTooManyRequests(reason='尝试次数过多，请五分钟后重试')
    ATTEMPTS[key].append(now)
    try:
        data = await request.json()
    except (ValueError, UnicodeDecodeError):
        raise web.HTTPBadRequest(reason='请求格式错误')
    if not isinstance(data, dict):
        raise web.HTTPBadRequest(reason='请求格式错误')
    username = data.get('username', '')
    password = data.get('password', '')
    if not isinstance(username, str) or not isinstance(password, str) or len(password) > 256:
        raise web.HTTPBadRequest(reason='账号格式错误')
    users = json.loads(USER_FILE.read_text(encoding='utf-8'))
    user = users.get(username)
    salt = bytes.fromhex(user['salt']) if user else bytes(32)
    digest = await asyncio.to_thread(hashlib.scrypt, password.encode(), salt=salt, n=16384, r=8, p=1)
    expected = user['password_hash'] if user else '0' * 128
    if not hmac.compare_digest(digest.hex(), expected) or not user or not user['enabled']:
        raise web.HTTPUnauthorized(reason='账号或密码错误')
    for token, session in list(SESSIONS.items()):
        if session['expires'] <= now:
            del SESSIONS[token]
    token = secrets.token_urlsafe(32)
    SESSIONS[token] = {'username': username, 'expires': now + 3600}
    response = web.json_response({'token': token, 'username': username, 'expires_in': 3600})
    set_download_cookie(response, request, token)
    return response


async def logout(request):
    token = request.headers.get('Authorization', '').removeprefix('Bearer ')
    SESSIONS.pop(token, None)
    digest = session_digest(token)
    for job in ENGINE.jobs.values():
        if job.get('download_session') == digest:
            for key in ('download_ticket', 'download_expires', 'download_session'):
                job.pop(key, None)
    response = web.json_response({'ok': True})
    response.del_cookie(DOWNLOAD_COOKIE, path='/files')
    return response


async def tasks(request):
    username = account(request)
    archive = archives_enabled(username)
    available = ENGINE.ready
    message = '工作站已连接。按接收顺序排队，下载确认后清理临时文件；等待你确认保存后清理，下载失败可重试。'
    if archive:
        message = '工作站已连接。按接收顺序排队，视频、提示词和上传的参考素材永久归档；归档后立即清理临时文件，下载直接读取归档视频。'
        try:
            archive_directory(username)
        except (OSError, ValueError):
            available = False
            message = '归档磁盘未就绪，附账号暂不能提交任务。'
    return web.json_response({'username': username, 'tasks': [ENGINE.summary(t) for t in ENGINE.jobs.values() if t['owner'] == username],
                             'accepting_tasks': available, 'archive': archive,
                             'models': allowed_models(username),
                             'dasiwa_turbo_lora_available': dasiwa_turbo_lora() is not None,
                             'dasiwa_turbo_lora_strength_available': True,
                             'yz_fight_lora_available': yz_fight_lora_available(),
                             'media_reference_available': True, 'aspect_ratio_available': True,
                             'native_download_post_available': True,
                             'message': message if ENGINE.ready else '工作站尚未就绪，请稍后重试。'})


def owned_job(request):
    username = account(request)
    job = ENGINE.jobs.get(request.match_info['id'])
    if not job or job['owner'] != username:
        raise web.HTTPNotFound(reason='任务不存在')
    return job


def save_image(data, path):
    with Image.open(io.BytesIO(data)) as image:
        if image.width * image.height > 16_000_000:
            raise ValueError('参考图片不得超过1600万像素')
        image.convert('RGB').save(path, format='PNG')


async def submit(request):
    username = account(request)
    if not ENGINE.ready:
        raise web.HTTPServiceUnavailable(reason='工作站尚未就绪')
    archive = archives_enabled(username)
    if archive:
        try:
            archive_directory(username)
        except (OSError, ValueError):
            raise web.HTTPServiceUnavailable(reason='归档磁盘未就绪，请连接后重试')
    if request.content_type != 'multipart/form-data':
        raise web.HTTPUnsupportedMediaType()
    try:
        job = ENGINE.new_job(username, archive=archive)
    except ValueError as exc:
        raise web.HTTPConflict(reason=str(exc))
    try:
        try:
            async with ENGINE.client.get('http://127.0.0.1:8188/queue') as response:
                original = await response.json()
                if original.get('queue_running') or original.get('queue_pending'):
                    raise web.HTTPConflict(reason='本机ComfyUI正在使用显卡，请稍后提交')
        except (OSError, asyncio.TimeoutError):
            pass
        if request.content_length and request.content_length > MAX_UPLOAD_BYTES:
            raise ValueError('任务总上传不得超过90MB')
        reader = await request.multipart()
        fields, images, videos, audios, total = {}, [], [], [], 0
        while part := await reader.next():
            if part.name in UPLOAD_LIMITS:
                has_filename = bool(part.filename)
                if has_filename and part.name == 'images' and len(images) >= 9:
                    raise ValueError('最多接收9张参考图')
                if has_filename and part.name in {'videos', 'audios'} and (videos if part.name == 'videos' else audios):
                    raise ValueError('视频和音频参考各最多上传1个')
                extension = Path(part.filename or '').suffix.lower()
                if has_filename and part.name in UPLOAD_EXTENSIONS and extension not in UPLOAD_EXTENSIONS[part.name]:
                    raise ValueError('视频或音频格式不受支持')
                data = bytearray()
                limit = UPLOAD_LIMITS[part.name]
                while chunk := await part.read_chunk(65536):
                    data.extend(chunk)
                    total += len(chunk)
                    if len(data) > limit:
                        raise ValueError(f'{part.name}文件不得超过{limit // (1024 * 1024)}MB')
                    if total > MAX_UPLOAD_BYTES:
                        raise ValueError('任务总上传不得超过90MB')
                if not data:
                    continue
                if not has_filename:
                    raise ValueError('上传文件缺少文件名')
                source_dir = RUNTIME / 'input' / job['id']
                if part.name == 'images':
                    relative = f'{job["id"]}/{len(images)+1}.png'
                    await asyncio.to_thread(save_image, data, RUNTIME / 'input' / relative)
                    images.append(relative)
                elif part.name == 'videos':
                    relative = f'{job["id"]}/ref_video_1{extension}'
                    (source_dir / f'ref_video_1{extension}').write_bytes(data)
                    videos.append(relative)
                else:
                    relative = f'{job["id"]}/ref_audio_1{extension}'
                    (source_dir / f'ref_audio_1{extension}').write_bytes(data)
                    audios.append(relative)
                continue
            data = bytearray()
            while chunk := await part.read_chunk(65536):
                data.extend(chunk)
                total += len(chunk)
                if total > MAX_UPLOAD_BYTES:
                    raise ValueError('任务总上传不得超过90MB')
            if part.name in {'prompt', 'seconds', 'orientation', 'aspect_ratio', 'model', 'resolution', 'seed', 'use_lora', 'lora_strength', 'use_yz_fight_lora', 'yz_fight_lora_strength', 'use_yz_dasiwa_lora', 'yz_dasiwa_lora_strength'}:
                if len(data) > 16000:
                    raise ValueError('文字内容过长')
                fields[part.name] = data.decode('utf-8')
            else:
                raise ValueError('未知任务参数')
        prompt = fields.get('prompt', '').strip()
        seconds = float(fields.get('seconds', '5.166666666666667'))
        orientation = fields.get('orientation', 'landscape')
        aspect_ratio = fields.get('aspect_ratio') or ('9:16' if orientation == 'portrait' else '16:9')
        resolution = fields.get('resolution', '720p')
        if resolution not in {'720p', '768p', '1080p'}:
            raise ValueError('请选择720p、768p或1080p')
        max_seconds = 30
        model = fields.get('model', 'yz-goldfish')
        use_lora_value = fields.get('use_lora', '')
        if use_lora_value not in {'', 'on', 'true', '1'}:
            raise ValueError('LoRA开关参数无效')
        use_lora = use_lora_value in {'on', 'true', '1'}
        yz_fight_lora_value = fields.get('use_yz_fight_lora', '')
        if yz_fight_lora_value not in {'', 'on', 'true', '1'}:
            raise ValueError('武打LoRA开关参数无效')
        use_yz_fight_lora = yz_fight_lora_value in {'on', 'true', '1'}
        yz_dasiwa_lora_value = fields.get('use_yz_dasiwa_lora', '')
        if yz_dasiwa_lora_value not in {'', 'on', 'true', '1'}:
            raise ValueError('DaSiWa LoRA开关参数无效')
        use_yz_dasiwa_lora = yz_dasiwa_lora_value in {'on', 'true', '1'}
        try:
            lora_strength = float(fields.get('lora_strength', '1'))
        except ValueError:
            raise ValueError('LoRA强度必须是0到1之间的数字')
        if not math.isfinite(lora_strength) or not 0 <= lora_strength <= 1:
            raise ValueError('LoRA强度必须在0到1之间')
        try:
            yz_fight_lora_strength = float(fields.get('yz_fight_lora_strength', '0.65'))
        except ValueError:
            raise ValueError('武打LoRA强度必须是0到1之间的数字')
        if not math.isfinite(yz_fight_lora_strength) or not 0 <= yz_fight_lora_strength <= 1:
            raise ValueError('武打LoRA强度必须在0到1之间')
        try:
            yz_dasiwa_lora_strength = float(fields.get('yz_dasiwa_lora_strength', '1'))
        except ValueError:
            raise ValueError('DaSiWa LoRA强度必须是0到1之间的数字')
        if not math.isfinite(yz_dasiwa_lora_strength) or not 0 <= yz_dasiwa_lora_strength <= 1:
            raise ValueError('DaSiWa LoRA强度必须在0到1之间')
        if use_lora and model != 'dasiwa-turbo-v3':
            raise ValueError('LoRA仅适用于DaSiWa Turbo V3')
        if use_lora and dasiwa_turbo_lora() is None:
            raise ValueError('DaSiWa Turbo LoRA 尚未安装完成')
        if use_yz_fight_lora and model != 'yz-goldfish':
            raise ValueError('武打LoRA仅适用于YZ金鱼工作流')
        if use_yz_fight_lora and not yz_fight_lora_available():
            raise ValueError('YZ 金鱼武打 LoRA 尚未安装完成')
        if use_yz_dasiwa_lora and model != 'yz-goldfish':
            raise ValueError('DaSiWa Turbo LoRA 仅适用于YZ金鱼或DaSiWa Turbo V3工作流')
        if use_yz_dasiwa_lora and dasiwa_turbo_lora() is None:
            raise ValueError('DaSiWa Turbo LoRA 尚未安装完成')
        if not any(m['id'] == model for m in allowed_models(username)):
            raise ValueError('请选择当前已开放的工作流')
        if model not in MODELS or not any(m['id'] == model and m['available'] for m in model_options()):
            raise ValueError('所选模型尚未安装或不可用')
        if not prompt or len(prompt) > 4000:
            raise ValueError('请填写提示词，最多4000字')
        if not 0.9 <= seconds <= max_seconds or aspect_ratio not in ASPECT_RATIOS:
            raise ValueError(f'画幅或时长参数不正确，{resolution}最多{max_seconds}秒')
        seed_text = fields.get('seed', '').strip()
        seed = int(seed_text) if seed_text else secrets.randbelow(2**53)
        if not 0 <= seed < 2**53:
            raise ValueError('种子超出有效范围')
        job.update(recipe={'prompt': prompt, 'seconds': seconds, 'orientation': orientation,
                           'aspect_ratio': aspect_ratio, 'model': model,
                           'images': images, 'videos': videos, 'audios': audios,
                           'resolution': resolution, 'seed': seed, 'use_lora': use_lora,
                           'lora_strength': lora_strength,
                           'use_yz_fight_lora': use_yz_fight_lora,
                           'yz_fight_lora_strength': yz_fight_lora_strength,
                           'use_yz_dasiwa_lora': use_yz_dasiwa_lora,
                           'yz_dasiwa_lora_strength': yz_dasiwa_lora_strength},
                   state='queued', message='等待工作站处理', updated=time.time())
        return web.json_response(ENGINE.summary(job), status=202)
    except (ValueError, UnicodeDecodeError, UnidentifiedImageError, Image.DecompressionBombError) as exc:
        ENGINE.clean_files(job)
        ENGINE.jobs.pop(job['id'], None)
        job['state'] = 'failed'
        raise web.HTTPBadRequest(reason=str(exc) if isinstance(exc, ValueError) else '图片格式不正确')
    except BaseException:
        ENGINE.clean_files(job)
        ENGINE.jobs.pop(job['id'], None)
        job['state'] = 'failed'
        raise
    finally:
        job['uploaded'].set()


async def download(request):
    job = owned_job(request)
    if job['state'] != 'ready':
        raise web.HTTPConflict(reason='结果尚不可下载')
    path = job['output']
    job['state'] = 'downloading'
    response = web.StreamResponse(headers={'Content-Type': 'application/octet-stream',
        'Content-Disposition': f'attachment; filename="{ENGINE.result_filename(job)}"',
        'Content-Length': str(path.stat().st_size), 'X-Download-Receipt': job['receipt'],
        'Access-Control-Expose-Headers': 'X-Download-Receipt, Content-Length', 'Cache-Control': 'no-store'})
    try:
        await response.prepare(request)
        with path.open('rb') as handle:
            while chunk := handle.read(256 * 1024):
                await response.write(chunk)
        await response.write_eof()
        job['delivered'] = True
        return response
    finally:
        job.update(state='ready', updated=time.time())


async def download_link(request):
    job = owned_job(request)
    if job['state'] != 'ready' or not job.get('output') or not job['output'].is_file():
        raise web.HTTPConflict(reason='结果尚不可下载')
    digest = session_digest(request_token(request))
    if job.get('download_expires', 0) < time.time() + 60 or job.get('download_session') != digest:
        job['download_ticket'] = secrets.token_urlsafe(32)
        job['download_expires'] = time.time() + 3600
        job['download_session'] = digest
    return web.json_response({'path': '/files/' + job['id'] + '/' + ENGINE.result_filename(job)
                              + '?ticket=' + job['download_ticket'],
                              'expires': job['download_expires'], 'receipt': job['receipt']})


async def native_download(request):
    job = ENGINE.jobs.get(request.match_info['id'])
    ticket = request.query.get('ticket', '')
    if (not job or not ticket or not job.get('download_ticket')
            or not hmac.compare_digest(ticket, job['download_ticket'])
            or job.get('download_expires', 0) <= time.time()
            or job['state'] != 'ready' or not job.get('output')
            or request.match_info['filename'] != ENGINE.result_filename(job)):
        raise web.HTTPNotFound(reason='下载链接无效或已过期，请回工作台重新获取')
    if request.method == 'POST':
        if request.content_length is None or request.content_length > 4096:
            raise web.HTTPBadRequest(reason='下载验证请求无效')
        data = await request.post()
        token = data.get('session', '')
        if not isinstance(token, str):
            raise web.HTTPUnauthorized(reason='请重新登录')
    else:
        token = request_token(request)
    session = SESSIONS.get(token)
    if not session or session['expires'] <= time.monotonic():
        raise web.HTTPUnauthorized(reason='请刷新工作台并点击“下载视频”，不要保存旧下载链接')
    if session['username'] != job['owner']:
        raise web.HTTPNotFound(reason='任务不存在')
    if request.method == 'POST':
        # Top-level form navigation is not a third-party cookie fetch. Authenticate
        # the owner from the POST body, set the first-party cookie, then let the
        # browser perform a native GET download (including Range/resume support).
        response = web.HTTPSeeOther(location=str(request.rel_url))
        set_download_cookie(response, request, token)
        return response
    # FileResponse serves full files and Range requests without buffering in JS.
    # Neither transfer completion nor disconnection deletes the result.
    return web.FileResponse(job['output'], headers={
        'Content-Type': 'application/octet-stream',
        'Content-Disposition': f'attachment; filename="{ENGINE.result_filename(job)}"',
        'Cache-Control': 'no-store', 'Referrer-Policy': 'no-referrer'})


async def downloaded(request):
    job = owned_job(request)
    data = await request.json()
    if not isinstance(data, dict):
        raise web.HTTPBadRequest()
    if data.get('confirmed_saved') is not True:
        raise web.HTTPConflict(reason='请确认视频已完整保存后再清理')
    if not (job['delivered'] or job.get('download_ticket')) or not hmac.compare_digest(str(data.get('receipt', '')), job['receipt']):
        raise web.HTTPConflict(reason='尚未完成下载传输')
    try:
        ENGINE.remove(job)
    except ValueError as exc:
        raise web.HTTPConflict(reason=str(exc))
    return web.json_response({'ok': True})


async def remove(request):
    job = owned_job(request)
    try:
        ENGINE.remove(job)
    except ValueError as exc:
        raise web.HTTPConflict(reason=str(exc))
    return web.json_response({'ok': True})


async def static(request):
    name = request.match_info.get('name') or 'index.html'
    if name not in {'index.html', 'app.js', 'style.css', 'config.js'}:
        raise web.HTTPNotFound()
    return web.FileResponse(ROOT / 'web' / name)


def make_app():
    app = web.Application(middlewares=[boundary], client_max_size=96 * 1024 * 1024)
    app.router.add_post('/api/login', login)
    app.router.add_post('/api/logout', logout)
    app.router.add_get('/api/tasks', tasks)
    app.router.add_post('/api/tasks', submit)
    app.router.add_post('/api/tasks/{id}/download-link', download_link)
    app.router.add_get('/files/{id}/{filename}', native_download)
    app.router.add_post('/files/{id}/{filename}', native_download)
    app.router.add_get('/api/tasks/{id}/download', download)
    app.router.add_post('/api/tasks/{id}/downloaded', downloaded)
    app.router.add_delete('/api/tasks/{id}', remove)
    app.router.add_route('OPTIONS', '/api/{path:.*}', lambda request: web.Response(status=204))
    app.router.add_get('/', static)
    app.router.add_get('/{name}', static)
    app.on_response_prepare.append(response_headers)
    return app


async def response_headers(request, response):
    response.headers['Cache-Control'] = 'no-store'
    response.headers['X-Content-Type-Options'] = 'nosniff'
    response.headers['Referrer-Policy'] = 'no-referrer'
    origin = request.headers.get('Origin')
    if origin and (origin in allowed_origins() or origin == f'{request.scheme}://{request.host}'):
        response.headers['Access-Control-Allow-Origin'] = origin
        response.headers['Access-Control-Allow-Credentials'] = 'true'
        response.headers['Vary'] = 'Origin'


async def monitor_status(request):
    return web.json_response({'ready': ENGINE.ready, 'tasks': [ENGINE.summary(j) for j in ENGINE.jobs.values()
                             if j['state'] in {'queued', 'running', 'downloading', 'archive_pending'}]}, headers={'Cache-Control':'no-store'})


async def monitor_page(request):
    return web.FileResponse(ROOT / 'monitor/status.html')


async def lifecycle(app):
    runner = None
    try:
        await ENGINE.start()
        monitor = web.Application()
        monitor.router.add_get('/', monitor_page)
        monitor.router.add_get('/status', monitor_status)
        runner = web.AppRunner(monitor, access_log=None)
        await runner.setup()
        await web.TCPSite(runner, '127.0.0.1', 8292).start()
        yield
    finally:
        if runner:
            await runner.cleanup()
        await ENGINE.close()


if __name__ == '__main__':
    lock = (ROOT / 'private/server.lock').open('a+b')
    lock.seek(0)
    if not lock.read(1):
        lock.write(b'0')
        lock.flush()
    lock.seek(0)
    try:
        msvcrt.locking(lock.fileno(), msvcrt.LK_NBLCK, 1)
    except OSError:
        raise SystemExit('H3 gateway is already running.')
    app = make_app()
    app.cleanup_ctx.append(lifecycle)
    web.run_app(app, host=PORTAL_HOST, port=8290, access_log=None, print=None)
